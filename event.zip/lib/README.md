# Event Booking App — Flutter

## File Structure

```
lib/
├── main.dart                          # App entry point
├── theme.dart                         # Colors, typography, theme
├── models/
│   └── listing.dart                   # Listing data model + fromMap/toMap
├── services/
│   └── database_service.dart          # ⚠️ Wire your DB here (Supabase/Firebase/REST)
├── widgets/
│   ├── app_top_bar.dart               # Shared top bar with logo + back/profile
│   ├── bottom_nav.dart                # Pill-shaped bottom navigation
│   └── listing_card.dart             # Reusable listing card (image + info)
└── screens/
    ├── home_screen.dart               # Home: hero banner + categories grid
    ├── search_screen.dart             # Manual search with live results
    ├── search_results_screen.dart     # Category results + map placeholder
    └── booking_screen.dart            # Listing detail + date picker + BOOK NOW
```

## Navigation Flow

```
HomeScreen
  ├── [Search bar tap] → SearchScreen (type to search)
  ├── [Category tap]   → SearchResultsScreen (filtered by category + city)
  └── [Bottom nav: search] → SearchScreen

SearchScreen / SearchResultsScreen
  └── [Listing tap] → BookingScreen

BookingScreen
  └── [BOOK NOW] → createBooking() in DatabaseService → success dialog
```

## Wiring Your Database

All database calls are in `lib/services/database_service.dart`.

Every method has a `// TODO:` comment showing exactly what to replace.

### Supabase example

```dart
// In main.dart, before runApp:
await Supabase.initialize(url: 'YOUR_URL', anonKey: 'YOUR_KEY');

// In database_service.dart:
final _client = Supabase.instance.client;

Future<List<Listing>> fetchListingsByCategoryAndCity(...) async {
  final response = await _client
      .from('listings')
      .select()
      .eq('category', category)
      .ilike('city', '%$city%');
  return (response as List).map((e) => Listing.fromMap(e)).toList();
}
```

### Firebase example

```dart
final _db = FirebaseFirestore.instance;

Future<List<Listing>> fetchListingsByCategoryAndCity(...) async {
  final snap = await _db.collection('listings')
      .where('category', isEqualTo: category)
      .where('city', isEqualTo: city)
      .get();
  return snap.docs.map((d) => Listing.fromMap(d.data())).toList();
}
```

## Map Integration

In `search_results_screen.dart`, look for the `// TODO: Replace with actual map widget` comment.

**Recommended package:** `flutter_map` (OpenStreetMap, no API key needed)

```yaml
# pubspec.yaml
dependencies:
  flutter_map: ^6.0.0
  latlong2: ^0.9.0
```

## pubspec.yaml additions needed

```yaml
dependencies:
  flutter:
    sdk: flutter
  # Add your DB package:
  # supabase_flutter: ^2.0.0
  # OR firebase_core + cloud_firestore
  
  # For map:
  # flutter_map: ^6.0.0
  # latlong2: ^0.9.0
```

## User City

In `home_screen.dart`, find `static const String _userCity = 'Algiers';`  
Replace this with your actual location/auth service call to get the user's city dynamically.

## User Auth ID

In `booking_screen.dart`, find `static const String _currentUserId = 'user_placeholder_id';`  
Replace with your auth service's current user ID.
