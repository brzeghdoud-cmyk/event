import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';
import '../models/listing.dart';
import '../services/database_service.dart';
import '../theme.dart';
import '../widgets/app_top_bar.dart';
import '../widgets/bottom_nav.dart';
import '../widgets/listing_card.dart';
import 'booking_screen.dart';
import '../widgets/profile_sheet.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _ctrl = TextEditingController();
  List<Listing> _results = [];
  List<Listing> _random = [];
  bool _loading = false;
  bool _searched = false;

  @override
  void initState() {
    super.initState();
    _loadRandom();
  }

  Future<void> _loadRandom() async {
    setState(() => _loading = true);
    final all = await DatabaseService.instance.searchListings('');
    if (mounted)
      setState(() {
        _random = all;
        _loading = false;
      });
  }

  Future<void> _search(String q) async {
    if (q.trim().isEmpty) {
      setState(() {
        _searched = false;
        _results = [];
      });
      return;
    }
    setState(() {
      _loading = true;
      _searched = true;
    });
    final r = await DatabaseService.instance.searchListings(q.trim());
    if (mounted)
      setState(() {
        _results = r;
        _loading = false;
      });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  List<Listing> get _display => _searched ? _results : _random;

  Widget _shimmer() => ListView.builder(
        itemCount: 5,
        itemBuilder: (_, __) => Shimmer.fromColors(
          baseColor: Colors.grey[200]!,
          highlightColor: Colors.grey[50]!,
          child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              height: 110,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16))),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppTopBar(onBack: () => Navigator.pop(context)),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
          child: TextField(
            controller: _ctrl,
            autofocus: true,
            onChanged: _search,
            decoration: InputDecoration(
              hintText: 'Search by name, city, category...',
              hintStyle: const TextStyle(color: AppTheme.textSecondary),
              prefixIcon: const Icon(Icons.search_rounded,
                  color: AppTheme.textSecondary),
              suffixIcon: _ctrl.text.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.close_rounded,
                          color: AppTheme.textSecondary),
                      onPressed: () {
                        _ctrl.clear();
                        _search('');
                      })
                  : null,
              filled: true,
              fillColor: AppTheme.surface,
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide:
                      const BorderSide(color: AppTheme.primary, width: 1.5)),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
          child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                  _searched
                      ? '${_results.length} result${_results.length != 1 ? 's' : ''}'
                      : 'Discover listings',
                  style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      color: AppTheme.textPrimary))),
        ),
        Expanded(
          child: _loading
              ? _shimmer()
              : _display.isEmpty
                  ? Center(
                      child: Text(
                          _searched
                              ? 'No results for "${_ctrl.text}"'
                              : 'No listings found',
                          style:
                              const TextStyle(color: AppTheme.textSecondary)))
                  : ListView.builder(
                      physics: const BouncingScrollPhysics(
                          parent: AlwaysScrollableScrollPhysics()),
                      padding: const EdgeInsets.only(bottom: 100),
                      itemCount: _display.length,
                      itemBuilder: (_, i) => ListingCard(
                        listing: _display[i],
                        onTap: () => Navigator.push(
                            context,
                            AppTheme.smoothRoute(
                                BookingScreen(listing: _display[i]))),
                      ),
                    ),
        ),
      ]),
      bottomNavigationBar: AppBottomNav(
        currentIndex: 1,
        onProfileTap: () {
          ProfileSheet.show(context, () {
            // Logic after logout (e.g., go to login screen)
            Navigator.pushReplacementNamed(context, '/login');
          });
        },
      ),
    );
  }
}
