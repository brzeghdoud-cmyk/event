import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';
import '../models/listing.dart';
import '../services/database_service.dart';
import '../theme.dart';
import '../widgets/app_top_bar.dart';
import '../widgets/bottom_nav.dart';
import '../widgets/listing_card.dart';
import 'booking_screen.dart';

class SearchResultsScreen extends StatefulWidget {
  final String category;
  final String categoryLabel;
  final String city;

  const SearchResultsScreen(
      {super.key,
      required this.category,
      required this.categoryLabel,
      required this.city});

  @override
  State<SearchResultsScreen> createState() => _SearchResultsScreenState();
}

class _SearchResultsScreenState extends State<SearchResultsScreen> {
  late Future<List<Listing>> _future;
  bool _showMap = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() {
    _future = DatabaseService.instance.fetchListingsByCategoryAndCity(
        category: widget.category, city: widget.city);
  }

  Widget _shimmer() => ListView.builder(
        itemCount: 5,
        itemBuilder: (_, __) => Shimmer.fromColors(
          baseColor: Colors.grey[200]!,
          highlightColor: Colors.grey[50]!,
          child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              height: 110,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16))),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppTopBar(onBack: () => Navigator.pop(context)),
      body: Column(children: [
        AnimatedSize(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
          child: _showMap
              ? Container(
                  height: 200,
                  color: Colors.grey[200],
                  child: Stack(children: [
                    Center(
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                          const Icon(Icons.map_outlined,
                              size: 48, color: AppTheme.textSecondary),
                          const SizedBox(height: 8),
                          Text('Map — ${widget.city}',
                              style: const TextStyle(
                                  color: AppTheme.textSecondary)),
                        ])),
                    Positioned(
                      top: 8,
                      right: 8,
                      child: GestureDetector(
                        onTap: () => setState(() => _showMap = false),
                        child: Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(8),
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.black.withOpacity(0.1),
                                    blurRadius: 4)
                              ]),
                          child: const Icon(Icons.close_rounded, size: 18),
                        ),
                      ),
                    ),
                  ]),
                )
              : const SizedBox.shrink(),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
          child: Row(children: [
            Expanded(
                child: Text('${widget.categoryLabel} in ${widget.city}',
                    style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: AppTheme.textPrimary))),
            if (!_showMap)
              TextButton.icon(
                onPressed: () => setState(() => _showMap = true),
                icon: const Icon(Icons.map_outlined, size: 18),
                label: const Text('Map'),
                style: TextButton.styleFrom(foregroundColor: AppTheme.primary),
              ),
          ]),
        ),
        Expanded(
          child: FutureBuilder<List<Listing>>(
            future: _future,
            builder: (context, snap) {
              if (snap.connectionState == ConnectionState.waiting)
                return _shimmer();
              if (snap.hasError)
                return Center(
                    child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.wifi_off_rounded,
                        size: 48, color: AppTheme.textSecondary),
                    const SizedBox(height: 12),
                    const Text('Could not load listings',
                        style: TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 16),
                    ElevatedButton.icon(
                        onPressed: () => setState(_load),
                        icon: const Icon(Icons.refresh_rounded),
                        label: const Text('Retry')),
                  ],
                ));
              final list = snap.data ?? [];
              if (list.isEmpty)
                return Center(
                    child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.search_off_rounded,
                        size: 48, color: AppTheme.textSecondary),
                    const SizedBox(height: 12),
                    Text('No ${widget.categoryLabel} in ${widget.city}',
                        style: const TextStyle(color: AppTheme.textSecondary)),
                  ],
                ));
              return ListView.builder(
                physics: const BouncingScrollPhysics(
                    parent: AlwaysScrollableScrollPhysics()),
                padding: const EdgeInsets.only(top: 4, bottom: 100),
                itemCount: list.length,
                itemBuilder: (_, i) => ListingCard(
                  listing: list[i],
                  onTap: () => Navigator.push(context,
                      AppTheme.smoothRoute(BookingScreen(listing: list[i]))),
                ),
              );
            },
          ),
        ),
      ]),
      /*bottomNavigationBar: AppBottomNav(
        currentIndex: 1,
        onTap: (i) { if (i == 0) Navigator.popUntil(context, (r) => r.isFirst); },
      ),*/
    );
  }
}
