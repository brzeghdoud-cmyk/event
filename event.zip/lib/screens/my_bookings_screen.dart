import 'package:flutter/material.dart';
import '../models/booking.dart';
import '../services/database_service.dart';
import '../services/chat_service.dart';
import '../theme.dart';

import 'chat_screen.dart';

class MyBookingsScreen extends StatefulWidget {
  const MyBookingsScreen({super.key});

  @override
  State<MyBookingsScreen> createState() => _MyBookingsScreenState();
}

class _MyBookingsScreenState extends State<MyBookingsScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs;
  List<UserBooking> _bookings = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 4, vsync: this);
    _load();
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final data = await DatabaseService.instance.getMyBookings();
      // Sort newest first
      data.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      if (mounted)
        setState(() {
          _bookings = data.cast<UserBooking>();
          _loading = false;
        });
    } catch (e) {
      if (mounted)
        setState(() {
          _error = e.toString().replaceAll('Exception: ', '');
          _loading = false;
        });
    }
  }

  List<UserBooking> _filtered(String status) => status == 'all'
      ? _bookings
      : _bookings.where((b) => b.status == status).toList();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon:
              const Icon(Icons.arrow_back_ios_rounded, color: AppTheme.primary),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'My Bookings',
          style: TextStyle(
              color: AppTheme.textPrimary,
              fontWeight: FontWeight.w800,
              fontSize: 18),
        ),
        bottom: TabBar(
          controller: _tabs,
          labelColor: AppTheme.primary,
          unselectedLabelColor: AppTheme.textSecondary,
          indicatorColor: AppTheme.primary,
          indicatorWeight: 2.5,
          labelStyle:
              const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
          tabs: const [
            Tab(text: 'All'),
            Tab(text: 'Pending'),
            Tab(text: 'Confirmed'),
            Tab(text: 'Other'),
          ],
        ),
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: AppTheme.primary))
          : _error != null
              ? _ErrorState(error: _error!, onRetry: _load)
              : RefreshIndicator(
                  color: AppTheme.primary,
                  onRefresh: _load,
                  child: TabBarView(
                    controller: _tabs,
                    children: [
                      _BookingList(bookings: _filtered('all'), onRetry: _load),
                      _BookingList(
                          bookings: _filtered('pending'), onRetry: _load),
                      _BookingList(
                          bookings: _filtered('confirmed'), onRetry: _load),
                      _BookingList(
                          bookings: _bookings
                              .where((b) =>
                                  b.status == 'rejected' ||
                                  b.status == 'cancelled')
                              .toList(),
                          onRetry: _load),
                    ],
                  ),
                ),
    );
  }
}

// ── Booking list ─────────────────────────────────────────────────────────────

class _BookingList extends StatelessWidget {
  final List<UserBooking> bookings;
  final VoidCallback onRetry;

  const _BookingList({required this.bookings, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    if (bookings.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.calendar_today_outlined,
                size: 52, color: AppTheme.textSecondary),
            SizedBox(height: 14),
            Text(
              'No bookings here',
              style: TextStyle(
                  color: AppTheme.textSecondary,
                  fontSize: 15,
                  fontWeight: FontWeight.w600),
            ),
          ],
        ),
      );
    }
    return ListView.separated(
      physics:
          const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
      itemCount: bookings.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (_, i) => _BookingCard(booking: bookings[i]),
    );
  }
}

// ── Booking card ─────────────────────────────────────────────────────────────

class _BookingCard extends StatefulWidget {
  final UserBooking booking;
  const _BookingCard({required this.booking});

  @override
  State<_BookingCard> createState() => _BookingCardState();
}

class _BookingCardState extends State<_BookingCard> {
  bool _chatLoading = false;

  Future<void> _openChat() async {
    final b = widget.booking;
    if (b.providerId == null) return;

    setState(() => _chatLoading = true);
    try {
      // If a thread already exists (chatThreadId stored on booking), use it.
      // Otherwise create/get one via ChatService.
      ChatThread thread;
      if (b.chatThreadId != null && b.chatThreadId!.isNotEmpty) {
        // Fetch thread list and find by id
        final threads = await ChatService.instance.getThreads();
        final found = threads
            .cast<ChatThread?>()
            .firstWhere((t) => t?.id == b.chatThreadId, orElse: () => null);
        if (found != null) {
          thread = found;
        } else {
          thread = await ChatService.instance
              .createThread(b.providerId!, b.listingId);
        }
      } else {
        thread =
            await ChatService.instance.createThread(b.providerId!, b.listingId);
      }
      if (mounted) {
        Navigator.push(
          context,
          AppTheme.smoothRoute(ChatDetailScreen(thread: thread)),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
                'Could not open chat: ${e.toString().replaceAll('Exception: ', '')}'),
            backgroundColor: AppTheme.error,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _chatLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final b = widget.booking;
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.cardBorder),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 3)),
        ],
      ),
      child: Column(
        children: [
          // ── Image + header ───────────────────────────────────────
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
            child: Stack(
              children: [
                SizedBox(
                  height: 130,
                  width: double.infinity,
                  child: b.listingImageUrl != null
                      ? Image.network(
                          b.listingImageUrl!,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                            color: AppTheme.surface,
                            child: const Icon(Icons.image_not_supported,
                                color: AppTheme.textSecondary, size: 36),
                          ),
                        )
                      : Container(
                          color: AppTheme.surface,
                          child: const Icon(Icons.photo_library_outlined,
                              color: AppTheme.textSecondary, size: 36),
                        ),
                ),
                // Status pill
                Positioned(
                  top: 10,
                  right: 10,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: b.statusColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      b.statusLabel,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.w700),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // ── Content ──────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  b.listingTitle,
                  style: const TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 15,
                      color: AppTheme.textPrimary),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                if (b.listingCity != null) ...[
                  const SizedBox(height: 2),
                  Text(
                    '${b.listingCity}, ${b.listingWilaya ?? ''}',
                    style: const TextStyle(
                        color: AppTheme.textSecondary, fontSize: 12),
                  ),
                ],
                const SizedBox(height: 12),

                // Details row
                Row(
                  children: [
                    _Detail(Icons.calendar_today_rounded, b.formattedDate),
                    const SizedBox(width: 16),
                    _Detail(Icons.people_rounded, '${b.guestCount} guests'),
                    const SizedBox(width: 16),
                    _Detail(Icons.payments_outlined, b.formattedPrice),
                  ],
                ),

                if (b.providerName != null && b.providerName!.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      const Icon(Icons.storefront_rounded,
                          size: 14, color: AppTheme.primary),
                      const SizedBox(width: 4),
                      Text(
                        b.providerName!,
                        style: const TextStyle(
                            color: AppTheme.primary,
                            fontSize: 12,
                            fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                ],

                const SizedBox(height: 14),

                // Chat button (always shown if provider exists)
                if (b.providerId != null)
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: _chatLoading ? null : _openChat,
                      icon: _chatLoading
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: AppTheme.primary))
                          : const Icon(Icons.chat_bubble_outline_rounded,
                              size: 16),
                      label: const Text('Chat with provider'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: AppTheme.primary,
                        side: const BorderSide(color: AppTheme.primary),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                        textStyle: const TextStyle(
                            fontSize: 13, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Detail extends StatelessWidget {
  final IconData icon;
  final String label;
  const _Detail(this.icon, this.label);

  @override
  Widget build(BuildContext context) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: AppTheme.textSecondary),
          const SizedBox(width: 4),
          Text(label,
              style: const TextStyle(
                  fontSize: 12,
                  color: AppTheme.textSecondary,
                  fontWeight: FontWeight.w500)),
        ],
      );
}

class _ErrorState extends StatelessWidget {
  final String error;
  final VoidCallback onRetry;
  const _ErrorState({required this.error, required this.onRetry});

  @override
  Widget build(BuildContext context) => Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.wifi_off_rounded,
                size: 48, color: AppTheme.textSecondary),
            const SizedBox(height: 12),
            Text(error,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    color: AppTheme.textSecondary, fontSize: 13)),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('Retry'),
            ),
          ],
        ),
      );
}
