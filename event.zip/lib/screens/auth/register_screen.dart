import 'package:flutter/material.dart';
import '../../services/auth_service.dart';
import '../../theme.dart';

class RegisterScreen extends StatefulWidget {
  final VoidCallback onSuccess;
  const RegisterScreen({super.key, required this.onSuccess});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _firstCtrl = TextEditingController();
  final _lastCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _confirmCtrl = TextEditingController();
  bool _obscure = true;
  bool _loading = false;
  String? _error;

  static final _phoneRegex = RegExp(r'^(\+213|0)(5|6|7)\d{8}$');

  Future<void> _register() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      await AuthService.instance.register(
        email: _emailCtrl.text,
        password: _passCtrl.text,
        firstName: _firstCtrl.text,
        lastName: _lastCtrl.text,
        phone: _phoneCtrl.text.trim().isEmpty ? null : _phoneCtrl.text.trim(),
      );
      if (mounted) {
        // Pop entire auth stack (register + login) then notify AuthGate
        Navigator.of(context).popUntil((route) => route.isFirst);
        widget.onSuccess();
      }
    } catch (e) {
      setState(() => _error = e.toString().replaceAll('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _firstCtrl.dispose();
    _lastCtrl.dispose();
    _emailCtrl.dispose();
    _phoneCtrl.dispose();
    _passCtrl.dispose();
    _confirmCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon:
              const Icon(Icons.arrow_back_ios_rounded, color: AppTheme.primary),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Create Account',
            style: TextStyle(
                color: AppTheme.textPrimary,
                fontWeight: FontWeight.w800,
                fontSize: 18)),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 28),
              if (_error != null)
                Container(
                  margin: const EdgeInsets.only(bottom: 16),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppTheme.error.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppTheme.error.withOpacity(0.3)),
                  ),
                  child: Row(children: [
                    const Icon(Icons.error_outline,
                        color: AppTheme.error, size: 18),
                    const SizedBox(width: 8),
                    Expanded(
                        child: Text(_error!,
                            style: const TextStyle(
                                color: AppTheme.error, fontSize: 13))),
                  ]),
                ),
              Row(children: [
                Expanded(
                    child: _Field(
                        label: 'First Name *',
                        child: TextFormField(
                            controller: _firstCtrl,
                            textCapitalization: TextCapitalization.words,
                            textInputAction: TextInputAction.next,
                            decoration:
                                const InputDecoration(hintText: 'ABDELILAH'),
                            validator: (v) => v == null || v.trim().isEmpty
                                ? 'Required'
                                : null))),
                const SizedBox(width: 12),
                Expanded(
                    child: _Field(
                        label: 'Last Name *',
                        child: TextFormField(
                            controller: _lastCtrl,
                            textCapitalization: TextCapitalization.words,
                            textInputAction: TextInputAction.next,
                            decoration: const InputDecoration(hintText: 'Sid'),
                            validator: (v) => v == null || v.trim().isEmpty
                                ? 'Required'
                                : null))),
              ]),
              const SizedBox(height: 16),
              _Field(
                  label: 'Email *',
                  child: TextFormField(
                      controller: _emailCtrl,
                      keyboardType: TextInputType.emailAddress,
                      textInputAction: TextInputAction.next,
                      decoration: const InputDecoration(
                          hintText: 'ba.sid@ensta.edu.dz',
                          prefixIcon: Icon(Icons.email_outlined,
                              color: AppTheme.textSecondary)),
                      validator: (v) => v == null || !v.contains('@')
                          ? 'Enter a valid email'
                          : null)),
              const SizedBox(height: 16),
              _Field(
                  label: 'Phone (optional)',
                  child: TextFormField(
                      controller: _phoneCtrl,
                      keyboardType: TextInputType.phone,
                      textInputAction: TextInputAction.next,
                      decoration: const InputDecoration(
                          hintText: '+213 or 05/06/07...',
                          prefixIcon: Icon(Icons.phone_outlined,
                              color: AppTheme.textSecondary)),
                      validator: (v) {
                        if (v == null || v.trim().isEmpty) return null;
                        return _phoneRegex.hasMatch(v.trim())
                            ? null
                            : 'Format: +213 5/6/7XXXXXXXX';
                      })),
              const SizedBox(height: 16),
              _Field(
                  label: 'Password *',
                  child: TextFormField(
                      controller: _passCtrl,
                      obscureText: _obscure,
                      textInputAction: TextInputAction.next,
                      decoration: InputDecoration(
                        hintText: 'Minimum 8 characters',
                        prefixIcon: const Icon(Icons.lock_outline,
                            color: AppTheme.textSecondary),
                        suffixIcon: IconButton(
                          icon: Icon(
                              _obscure
                                  ? Icons.visibility_off_outlined
                                  : Icons.visibility_outlined,
                              color: AppTheme.textSecondary),
                          onPressed: () => setState(() => _obscure = !_obscure),
                        ),
                      ),
                      validator: (v) => v == null || v.length < 8
                          ? 'Minimum 8 characters'
                          : null)),
              const SizedBox(height: 16),
              _Field(
                  label: 'Confirm Password *',
                  child: TextFormField(
                      controller: _confirmCtrl,
                      obscureText: _obscure,
                      textInputAction: TextInputAction.done,
                      onFieldSubmitted: (_) => _register(),
                      decoration: const InputDecoration(
                          hintText: 'Repeat your password',
                          prefixIcon: Icon(Icons.lock_outline,
                              color: AppTheme.textSecondary)),
                      validator: (v) => v != _passCtrl.text
                          ? 'Passwords do not match'
                          : null)),
              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _loading ? null : _register,
                  child: _loading
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                              color: Colors.white, strokeWidth: 2.5))
                      : const Text('Create Account'),
                ),
              ),
              const SizedBox(height: 16),
              Center(
                  child: GestureDetector(
                onTap: () => Navigator.pop(context),
                child: RichText(
                  text: const TextSpan(
                    text: 'Already have an account? ',
                    style: TextStyle(color: AppTheme.textSecondary),
                    children: [
                      TextSpan(
                          text: 'Sign In',
                          style: TextStyle(
                              color: AppTheme.primary,
                              fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              )),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }
}

class _Field extends StatelessWidget {
  final String label;
  final Widget child;
  const _Field({required this.label, required this.child});

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textSecondary)),
          const SizedBox(height: 6),
          child,
        ],
      );
}
