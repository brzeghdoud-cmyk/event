import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import '../theme.dart';
import '../widgets/app_top_bar.dart';
import '../widgets/bottom_nav.dart';
import 'search_results_screen.dart';
import 'search_screen.dart';
import 'chat_screen.dart';
import '../widgets/profile_sheet.dart';

class Category {
  final String id;
  final String label;
  final IconData icon;
  const Category({required this.id, required this.label, required this.icon});
}

const List<Category> categories = [
  Category(id: 'venue', label: 'Events room', icon: Icons.business_rounded),
  Category(
      id: 'photographer', label: 'Photographe', icon: Icons.camera_alt_rounded),
  Category(id: 'dj', label: 'Dj', icon: Icons.music_note_rounded),
  Category(
      id: 'decorator', label: 'Decoration', icon: Icons.auto_awesome_rounded),
];

class HomeScreen extends StatefulWidget {
  final VoidCallback? onLogout;
  const HomeScreen({super.key, this.onLogout});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _navIndex = 0;
  static const String _userCity = 'Algiers';

  void _showProfileSheet() {
    final user = AuthService.instance.currentUser;
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
                color: AppTheme.cardBorder,
                borderRadius: BorderRadius.circular(2)),
          ),
          const SizedBox(height: 20),
          CircleAvatar(
            radius: 32,
            backgroundColor: AppTheme.primary.withOpacity(0.1),
            child: Text(
              user?.firstName.isNotEmpty == true
                  ? user!.firstName[0].toUpperCase()
                  : '?',
              style: const TextStyle(
                  color: AppTheme.primary,
                  fontSize: 24,
                  fontWeight: FontWeight.w800),
            ),
          ),
          const SizedBox(height: 12),
          Text(user?.fullName ?? 'Guest',
              style: const TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 18,
                  color: AppTheme.textPrimary)),
          Text(user?.email ?? '',
              style:
                  const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () async {
                Navigator.pop(context);
                await AuthService.instance.logout();
                widget.onLogout?.call();
              },
              icon: const Icon(Icons.logout_rounded, color: AppTheme.error),
              label: const Text('Sign Out',
                  style: TextStyle(color: AppTheme.error)),
              style: OutlinedButton.styleFrom(
                side: BorderSide(color: AppTheme.error.withOpacity(0.4)),
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  void _onCategoryTap(Category cat) {
    Navigator.push(
        context,
        AppTheme.smoothRoute(SearchResultsScreen(
            category: cat.id, categoryLabel: cat.label, city: _userCity)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppTopBar(onBack: null),
      body: ListView(
        physics: const BouncingScrollPhysics(
            parent: AlwaysScrollableScrollPhysics()),
        children: [
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                  colors: [AppTheme.primary, AppTheme.accent],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(20),
            ),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Book your Algerian event\ninstantly & securely',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      height: 1.3)),
              const SizedBox(height: 8),
              const Text('trouvez la salle parfaite pour vos mariages et fêtes',
                  style: TextStyle(color: Colors.white70, fontSize: 13)),
              const SizedBox(height: 16),
              GestureDetector(
                onTap: () => Navigator.push(
                    context, AppTheme.smoothRoute(const SearchScreen())),
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12)),
                  child: const Row(children: [
                    Icon(Icons.search_rounded,
                        color: AppTheme.textSecondary, size: 20),
                    SizedBox(width: 10),
                    Text('Alger, Oran, Constantine...',
                        style: TextStyle(
                            color: AppTheme.textSecondary, fontSize: 15)),
                  ]),
                ),
              ),
            ]),
          ),
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 8, 16, 16),
            child: Text('Categories',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: AppTheme.textPrimary)),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.4,
              children: categories
                  .map((cat) => _CategoryCard(
                      category: cat, onTap: () => _onCategoryTap(cat)))
                  .toList(),
            ),
          ),
          const SizedBox(height: 100),
        ],
      ),
      bottomNavigationBar: AppBottomNav(
        currentIndex: 0,
        onProfileTap: () =>
            ProfileSheet.show(context, widget.onLogout ?? () {}),
      ),
    );
  }
}

class _CategoryCard extends StatelessWidget {
  final Category category;
  final VoidCallback onTap;
  const _CategoryCard({required this.category, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.cardBorder),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 8,
                  offset: const Offset(0, 2))
            ],
          ),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(category.icon, size: 36, color: AppTheme.textPrimary),
            const SizedBox(height: 8),
            Text(category.label,
                style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.textPrimary)),
          ]),
        ),
      );
}
