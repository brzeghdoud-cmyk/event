import 'package:flutter/material.dart';
import '../models/listing.dart';
import '../services/auth_service.dart';
import '../services/database_service.dart';
import '../services/chat_service.dart';
import '../theme.dart';
import '../widgets/app_top_bar.dart';

class BookingScreen extends StatefulWidget {
  final Listing listing;
  const BookingScreen({super.key, required this.listing});

  @override
  State<BookingScreen> createState() => _BookingScreenState();
}

class _BookingScreenState extends State<BookingScreen> {
  DateTime? _selectedDate;
  int _guestCount = 50;
  bool _isBooking = false;
  bool _bookPressed = false;
  int _currentImageIndex = 0;
  final PageController _pageController = PageController();

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: now.add(const Duration(days: 7)),
      firstDate: now,
      lastDate: now.add(const Duration(days: 365 * 2)),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(
            colorScheme: const ColorScheme.light(primary: AppTheme.primary)),
        child: child!,
      ),
    );
    if (picked != null) setState(() => _selectedDate = picked);
  }

  Future<void> _confirmBooking() async {
    if (_selectedDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please select an event date first.')));
      return;
    }

    final user = AuthService.instance.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please sign in to book.')));
      return;
    }

    setState(() => _isBooking = true);

    try {
      // Only send fields the validator accepts
      final success = await DatabaseService.instance.createBooking(
        listingId: widget.listing.id,
        userId: user.id,
        eventDate: _selectedDate!,
        guestCount: _guestCount,
      );

      if (!mounted) return;

      if (success) {
        // Send booking notification via chat to provider
        if (widget.listing.providerId != null) {
          try {
            await ChatService.instance.sendBookingNotification(
              providerId: widget.listing.providerId!,
              listingId: widget.listing.id,
              listingName: widget.listing.name,
              eventDate: _selectedDate!,
              guestCount: _guestCount,
              formattedPrice: widget.listing.formattedPrice,
            );
          } catch (_) {
            // Chat notification failed silently — booking still succeeded
          }
        }
        _showSuccessDialog();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(e.toString().replaceAll('Exception: ', '')),
          backgroundColor: AppTheme.error,
        ));
      }
    } finally {
      if (mounted) setState(() => _isBooking = false);
    }
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Column(children: [
          Icon(Icons.check_circle_rounded, color: AppTheme.primary, size: 56),
          SizedBox(height: 12),
          Text('Booking Request Sent!',
              textAlign: TextAlign.center,
              style: TextStyle(fontWeight: FontWeight.w800)),
        ]),
        content: Text(
          'Your request for "${widget.listing.name}" has been sent.\nThe provider will confirm shortly.',
          textAlign: TextAlign.center,
          style: const TextStyle(color: AppTheme.textSecondary),
        ),
        actions: [
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                Navigator.pop(context); // close dialog
                Navigator.pop(context); // back to results
              },
              child: const Text('Done'),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final listing = widget.listing;

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppTopBar(onBack: () => Navigator.pop(context)),
      body: ListView(
        physics: const BouncingScrollPhysics(
            parent: AlwaysScrollableScrollPhysics()),
        padding: EdgeInsets.zero,
        children: [
          // ── Image Gallery ────────────────────────────────────────────────
          SizedBox(
            height: 250,
            child: Stack(children: [
              PageView.builder(
                controller: _pageController,
                itemCount:
                    listing.imageUrls.isEmpty ? 1 : listing.imageUrls.length,
                onPageChanged: (i) => setState(() => _currentImageIndex = i),
                itemBuilder: (_, i) => listing.imageUrls.isNotEmpty
                    ? Image.network(
                        listing.imageUrls[i],
                        fit: BoxFit.cover,
                        width: double.infinity,
                        loadingBuilder: (_, child, p) {
                          if (p == null) return child;
                          return Container(
                              color: AppTheme.surface,
                              child: const Center(
                                  child: CircularProgressIndicator(
                                      color: AppTheme.primary,
                                      strokeWidth: 2)));
                        },
                        errorBuilder: (_, __, ___) => Container(
                            color: AppTheme.surface,
                            child: const Icon(Icons.image_not_supported,
                                size: 64, color: AppTheme.textSecondary)),
                      )
                    : Container(
                        color: AppTheme.surface,
                        child: const Center(
                            child: Icon(Icons.photo_library_outlined,
                                size: 64, color: AppTheme.textSecondary))),
              ),
              if (listing.has360Tour)
                Positioned(
                  bottom: 12,
                  left: 12,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                        color: Colors.green,
                        borderRadius: BorderRadius.circular(8)),
                    child: const Text('VISITE 360° DISPONIBLE',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.w700)),
                  ),
                ),
              if (listing.isVerified)
                Positioned(
                  top: 12,
                  right: 12,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                        color: AppTheme.primary,
                        borderRadius: BorderRadius.circular(8)),
                    child: const Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.verified_rounded,
                          color: Colors.white, size: 12),
                      SizedBox(width: 4),
                      Text('Verified',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 11,
                              fontWeight: FontWeight.w700)),
                    ]),
                  ),
                ),
              if (listing.imageUrls.length > 1)
                Positioned(
                  bottom: 12,
                  right: 12,
                  child: Row(
                    children: List.generate(
                      listing.imageUrls.length,
                      (i) => AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        margin: const EdgeInsets.symmetric(horizontal: 2),
                        width: i == _currentImageIndex ? 16 : 6,
                        height: 6,
                        decoration: BoxDecoration(
                          color: i == _currentImageIndex
                              ? AppTheme.primary
                              : Colors.white70,
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ),
                    ),
                  ),
                ),
            ]),
          ),

          Padding(
            padding: const EdgeInsets.all(16),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              // Name + Price
              Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Expanded(
                  child: Text(listing.name,
                      style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.textPrimary)),
                ),
                const SizedBox(width: 12),
                Text(listing.formattedPrice,
                    style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: AppTheme.priceColor)),
              ]),

              const SizedBox(height: 6),
              Row(children: [
                const Icon(Icons.location_on_rounded,
                    size: 16, color: AppTheme.textSecondary),
                const SizedBox(width: 4),
                Expanded(
                    child: Text('${listing.city}, ${listing.wilaya}',
                        style: const TextStyle(
                            fontSize: 13, color: AppTheme.textSecondary))),
              ]),

              const SizedBox(height: 4),
              Row(children: [
                const Icon(Icons.star_rounded,
                    size: 16, color: AppTheme.starColor),
                const SizedBox(width: 4),
                Text(
                    '${listing.rating.toStringAsFixed(1)} (${listing.reviewCount} reviews)',
                    style: const TextStyle(
                        fontSize: 13, color: AppTheme.textSecondary)),
              ]),

              const SizedBox(height: 20),

              _Label('DESCRIPTION'),
              const SizedBox(height: 8),
              Text(listing.description,
                  style: const TextStyle(
                      fontSize: 14, color: AppTheme.textPrimary, height: 1.6)),

              const SizedBox(height: 20),

              Row(children: [
                Expanded(
                    child: _Chip(
                        label: 'CAPACITY',
                        value:
                            '${listing.capacityMin}–${listing.capacityMax} guests')),
                const SizedBox(width: 12),
                Expanded(
                    child: _Chip(
                        label: 'PRICE RANGE',
                        value:
                            '${listing.priceMin.toInt()}–${listing.priceMax.toInt()} ${listing.currency}')),
              ]),

              const SizedBox(height: 24),

              // Date picker
              _Label('EVENT DATE'),
              const SizedBox(height: 8),
              GestureDetector(
                onTap: _pickDate,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  decoration: BoxDecoration(
                    color: AppTheme.surface,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                        color: _selectedDate != null
                            ? AppTheme.primary
                            : AppTheme.cardBorder),
                  ),
                  child: Row(children: [
                    const Icon(Icons.calendar_today_rounded,
                        size: 20, color: AppTheme.primary),
                    const SizedBox(width: 12),
                    Text(
                      _selectedDate == null
                          ? 'Select event date'
                          : '${_selectedDate!.day}/${_selectedDate!.month}/${_selectedDate!.year}',
                      style: TextStyle(
                        fontSize: 15,
                        color: _selectedDate == null
                            ? AppTheme.textSecondary
                            : AppTheme.textPrimary,
                        fontWeight: _selectedDate != null
                            ? FontWeight.w600
                            : FontWeight.normal,
                      ),
                    ),
                    const Spacer(),
                    const Icon(Icons.arrow_forward_ios_rounded,
                        size: 16, color: AppTheme.textSecondary),
                  ]),
                ),
              ),

              const SizedBox(height: 20),

              // Guest counter
              _Label('NUMBER OF GUESTS'),
              const SizedBox(height: 8),
              Row(children: [
                _Counter(
                  icon: Icons.remove_rounded,
                  onTap: () {
                    if (_guestCount > listing.capacityMin) {
                      setState(() => _guestCount = (_guestCount - 10)
                          .clamp(listing.capacityMin, listing.capacityMax));
                    }
                  },
                ),
                Expanded(
                  child: Center(
                    child: Text('$_guestCount',
                        style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                            color: AppTheme.textPrimary)),
                  ),
                ),
                _Counter(
                  icon: Icons.add_rounded,
                  onTap: () {
                    if (_guestCount < listing.capacityMax) {
                      setState(() => _guestCount = (_guestCount + 10)
                          .clamp(listing.capacityMin, listing.capacityMax));
                    }
                  },
                ),
              ]),
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(
                    'Min ${listing.capacityMin} · Max ${listing.capacityMax}',
                    style: const TextStyle(
                        fontSize: 12, color: AppTheme.textSecondary)),
              ),

              const SizedBox(height: 32),

              // Book Now
              GestureDetector(
                onTapDown: (_) => setState(() => _bookPressed = true),
                onTapUp: (_) => setState(() => _bookPressed = false),
                onTapCancel: () => setState(() => _bookPressed = false),
                child: AnimatedScale(
                  scale: _bookPressed ? 0.97 : 1.0,
                  duration: const Duration(milliseconds: 100),
                  child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _isBooking ? null : _confirmBooking,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.primary,
                        disabledBackgroundColor:
                            AppTheme.primary.withOpacity(0.6),
                        padding: const EdgeInsets.symmetric(vertical: 18),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16)),
                      ),
                      child: _isBooking
                          ? const SizedBox(
                              height: 22,
                              width: 22,
                              child: CircularProgressIndicator(
                                  color: Colors.white, strokeWidth: 2.5))
                          : const Text('BOOK NOW',
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 1.2)),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 32),
            ]),
          ),
        ],
      ),
    );
  }
}

class _Label extends StatelessWidget {
  final String text;
  const _Label(this.text);
  @override
  Widget build(BuildContext context) => Text(text,
      style: const TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.3,
          color: AppTheme.primary));
}

class _Chip extends StatelessWidget {
  final String label, value;
  const _Chip({required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
            color: AppTheme.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppTheme.cardBorder)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label,
              style: const TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 1,
                  color: AppTheme.textSecondary)),
          const SizedBox(height: 4),
          Text(value,
              style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.textPrimary)),
        ]),
      );
}

class _Counter extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _Counter({required this.icon, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
              border: Border.all(color: AppTheme.cardBorder),
              borderRadius: BorderRadius.circular(12)),
          child: Icon(icon, size: 20, color: AppTheme.primary),
        ),
      );
}
