import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class AuthUser {
  final String id;
  final String email;
  final String firstName;
  final String lastName;
  final String role;
  final String? phone;
  final String? avatarUrl;
  final bool isVerified;
  final String accessToken;
  final String refreshToken;

  const AuthUser({
    required this.id,
    required this.email,
    required this.firstName,
    required this.lastName,
    required this.role,
    this.phone,
    this.avatarUrl,
    required this.isVerified,
    required this.accessToken,
    required this.refreshToken,
  });

  String get fullName => '$firstName $lastName';

  factory AuthUser.fromMap(
      Map<String, dynamic> map, String access, String refresh) {
    return AuthUser(
      id: map['_id'] ?? map['id'] ?? '',
      email: map['email'] ?? '',
      firstName: map['firstName'] ?? '',
      lastName: map['lastName'] ?? '',
      role: map['role'] ?? 'client',
      phone: map['phone'],
      avatarUrl: map['avatarUrl'],
      isVerified: map['isVerified'] ?? false,
      accessToken: access,
      refreshToken: refresh,
    );
  }
}

class AuthService {
  static final AuthService instance = AuthService._();
  AuthService._();

  static const String _base = 'https://eventrepo-yn7f.onrender.com/api/v1';

  AuthUser? _user;
  String? _accessToken;
  String? _refreshToken;

  AuthUser? get currentUser => _user;
  String? get accessToken => _accessToken;
  bool get isLoggedIn => _user != null;

  Map<String, String> get authHeaders => {
        'Content-Type': 'application/json',
        if (_accessToken != null) 'Authorization': 'Bearer $_accessToken',
      };

  // ── Persist session ────────────────────────────────────────────────────────

  Future<bool> restoreSession() async {
    final prefs = await SharedPreferences.getInstance();
    _accessToken = prefs.getString('ev_access');
    _refreshToken = prefs.getString('ev_refresh');
    if (_accessToken == null) return false;
    try {
      final res =
          await http.get(Uri.parse('$_base/users/me'), headers: authHeaders);
      if (res.statusCode == 200) {
        final body = jsonDecode(res.body) as Map<String, dynamic>;
        final data = body['data'] as Map<String, dynamic>? ?? body;
        _user = AuthUser.fromMap(data, _accessToken!, _refreshToken ?? '');
        return true;
      }
    } catch (_) {}
    await clearSession();
    return false;
  }

  Future<void> _saveSession(String access, String refresh) async {
    _accessToken = access;
    _refreshToken = refresh;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('ev_access', access);
    await prefs.setString('ev_refresh', refresh);
  }

  Future<void> clearSession() async {
    _user = null;
    _accessToken = null;
    _refreshToken = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('ev_access');
    await prefs.remove('ev_refresh');
  }

  // ── Register ───────────────────────────────────────────────────────────────

  Future<AuthUser> register({
    required String email,
    required String password,
    required String firstName,
    required String lastName,
    String? phone,
  }) async {
    final res = await http.post(
      Uri.parse('$_base/auth/register'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'email': email.trim().toLowerCase(),
        'password': password,
        'firstName': firstName.trim(),
        'lastName': lastName.trim(),
        'role': 'client',
        if (phone != null && phone.trim().isNotEmpty) 'phone': phone.trim(),
      }),
    );
    return _handleAuth(res);
  }

  // ── Login ──────────────────────────────────────────────────────────────────

  Future<AuthUser> login({
    required String email,
    required String password,
  }) async {
    final res = await http.post(
      Uri.parse('$_base/auth/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'email': email.trim().toLowerCase(),
        'password': password,
      }),
    );
    return _handleAuth(res);
  }

  Future<AuthUser> _handleAuth(http.Response res) async {
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200 && res.statusCode != 201) {
      throw Exception(body['message'] ?? 'Auth failed');
    }
    final data = body['data'] as Map<String, dynamic>? ?? body;
    final access = data['accessToken'] ?? data['token'] ?? '';
    final refresh = data['refreshToken'] ?? '';
    final userMap = data['user'] as Map<String, dynamic>? ?? data;
    _user = AuthUser.fromMap(userMap, access, refresh);
    await _saveSession(access, refresh);
    return _user!;
  }

  // ── Logout ─────────────────────────────────────────────────────────────────

  Future<void> logout() async {
    try {
      await http.post(Uri.parse('$_base/auth/logout'),
          headers: authHeaders,
          body: jsonEncode({'refreshToken': _refreshToken ?? ''}));
    } catch (_) {}
    await clearSession();
  }
}
