import 'dart:convert';
import 'package:http/http.dart' as http;
import 'auth_service.dart';

class ChatThread {
  final String id;
  final String otherUserId;
  final String otherUserName;
  final String? otherUserAvatar;
  final String? listingId;
  final String? listingTitle;
  final String lastMessage;
  final DateTime lastMessageAt;
  final int unreadCount;

  const ChatThread({
    required this.id,
    required this.otherUserId,
    required this.otherUserName,
    this.otherUserAvatar,
    this.listingId,
    this.listingTitle,
    required this.lastMessage,
    required this.lastMessageAt,
    required this.unreadCount,
  });

  factory ChatThread.fromMap(Map<String, dynamic> map, String myId) {
    final parts =
        (map['participants'] as List?)?.cast<Map<String, dynamic>>() ?? [];
    final other = parts.firstWhere(
      (p) => (p['_id'] ?? p['id'] ?? '').toString() != myId,
      orElse: () => parts.isNotEmpty ? parts.first : {},
    );
    final listing = map['listing'] as Map<String, dynamic>?;

    // unreadCount is a Map on backend — get my unread count
    int unread = 0;
    final uc = map['unreadCount'];
    if (uc is Map) {
      unread = (uc[myId] as num?)?.toInt() ?? 0;
    }

    return ChatThread(
      id: map['_id'] ?? map['id'] ?? '',
      otherUserId: (other['_id'] ?? other['id'] ?? '').toString(),
      otherUserName:
          '${other['firstName'] ?? ''} ${other['lastName'] ?? ''}'.trim(),
      otherUserAvatar: other['avatarUrl'],
      listingId: listing?['_id'] ?? listing?['id'],
      listingTitle: listing?['title'],
      lastMessage: map['lastMessage'] ?? '',
      lastMessageAt:
          DateTime.tryParse(map['lastMessageAt'] ?? map['updatedAt'] ?? '') ??
              DateTime.now(),
      unreadCount: unread,
    );
  }
}

class ChatMessage {
  final String id;
  final String senderId;
  final String content;
  final String type;
  final DateTime createdAt;
  final bool isMe;

  const ChatMessage({
    required this.id,
    required this.senderId,
    required this.content,
    required this.type,
    required this.createdAt,
    required this.isMe,
  });

  factory ChatMessage.fromMap(Map<String, dynamic> map, String myId) {
    final sender = map['sender'];
    final sid = sender is Map
        ? (sender['_id'] ?? sender['id'] ?? '').toString()
        : (sender ?? '').toString();
    return ChatMessage(
      id: map['_id'] ?? map['id'] ?? '',
      senderId: sid,
      content: map['content'] ?? '',
      type: map['type'] ?? 'text',
      createdAt: DateTime.tryParse(map['createdAt'] ?? '') ?? DateTime.now(),
      isMe: sid == myId,
    );
  }
}

class ChatService {
  static final ChatService instance = ChatService._();
  ChatService._();

  static const String _base = 'https://eventrepo-yn7f.onrender.com/api/v1';

  String get _myId => AuthService.instance.currentUser?.id ?? '';
  Map<String, String> get _h => AuthService.instance.authHeaders;

  // ── Threads ────────────────────────────────────────────────────────────────

  Future<List<ChatThread>> getThreads() async {
    final res = await http.get(Uri.parse('$_base/chat/threads'), headers: _h);
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200)
      throw Exception(body['message'] ?? 'Failed to load chats');
    final raw = body['data'] as List? ?? [];
    // parse safely — skip any thread that fails to parse
    final threads = <ChatThread>[];
    for (final e in raw) {
      try {
        threads.add(ChatThread.fromMap(e as Map<String, dynamic>, _myId));
      } catch (_) {}
    }
    return threads;
  }

  /// Creates or reuses a thread. Backend expects 'recipientId' not 'participantId'.
  Future<ChatThread> createThread(String recipientId, String listingId) async {
    final res = await http.post(
      Uri.parse('$_base/chat/threads'),
      headers: _h,
      body: jsonEncode({
        'recipientId': recipientId, // ✅ fixed field name
        'listingId': listingId,
      }),
    );
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200 && res.statusCode != 201) {
      throw Exception(body['message'] ?? 'Failed to create chat');
    }
    // backend returns { data: { thread: {...} } }
    final data = body['data'] as Map<String, dynamic>? ?? {};
    final threadMap = data['thread'] as Map<String, dynamic>? ?? data;
    return ChatThread.fromMap(threadMap, _myId);
  }

  // ── Messages ───────────────────────────────────────────────────────────────

  /// Backend returns newest-first (desc), we reverse so oldest is at top.
  Future<List<ChatMessage>> getMessages(String threadId) async {
    final res = await http
        .get(Uri.parse('$_base/chat/threads/$threadId/messages'), headers: _h);
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200) throw Exception(body['message'] ?? 'Failed');
    final msgs = (body['data'] as List? ?? [])
        .map((e) => ChatMessage.fromMap(e as Map<String, dynamic>, _myId))
        .toList();
    msgs.sort((a, b) => a.createdAt.compareTo(b.createdAt));
    return msgs;
  }

  Future<ChatMessage> sendMessage(String threadId, String content) async {
    final res = await http.post(
      Uri.parse('$_base/chat/threads/$threadId/messages'),
      headers: _h,
      body: jsonEncode({'content': content}),
    );
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200 && res.statusCode != 201) {
      throw Exception(body['message'] ?? 'Failed to send message');
    }
    // backend returns { data: { message: {...} } }
    final data = body['data'] as Map<String, dynamic>? ?? {};
    final msgMap = data['message'] as Map<String, dynamic>? ?? data;
    return ChatMessage.fromMap(msgMap, _myId);
  }

  Future<void> markRead(String threadId) async {
    await http.patch(
      Uri.parse('$_base/chat/threads/$threadId/read'),
      headers: _h,
    );
  }

  // ── Booking notification ───────────────────────────────────────────────────

  Future<void> sendBookingNotification({
    required String providerId,
    required String listingId,
    required String listingName,
    required DateTime eventDate,
    required int guestCount,
    required String formattedPrice,
  }) async {
    try {
      final thread = await createThread(providerId, listingId);
      final msg = '📅 New Booking Request\n\n'
          'Listing: $listingName\n'
          'Date: ${eventDate.day}/${eventDate.month}/${eventDate.year}\n'
          'Guests: $guestCount\n'
          'Price: $formattedPrice\n\n'
          'Please confirm or reject this booking.';
      await sendMessage(thread.id, msg);
    } catch (_) {
      // fire-and-forget — don't fail the booking if chat fails
    }
  }
}
