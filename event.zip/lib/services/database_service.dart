import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/listing.dart';
import '../models/booking.dart';
import 'auth_service.dart';

class DatabaseService {
  static final DatabaseService instance = DatabaseService._();
  DatabaseService._();

  static const String _base = 'https://eventrepo-yn7f.onrender.com/api/v1';

  Map<String, String> get _headers => AuthService.instance.authHeaders;

  // ── Listings ───────────────────────────────────────────────────────────────

  Future<List<Listing>> _fetch(Map<String, String> params) async {
    final uri = Uri.parse('$_base/listings').replace(queryParameters: params);
    final res = await http.get(uri, headers: _headers);
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200) {
      throw Exception(body['message'] ?? 'Failed to load listings');
    }
    final data = body['data'] as List? ?? [];
    return data.map((e) => Listing.fromMap(e as Map<String, dynamic>)).toList();
  }

  Future<List<Listing>> fetchListingsByCategoryAndCity({
    required String category,
    required String city,
  }) =>
      _fetch({'category': category, 'city': city});

  // ── Search ─────────────────────────────────────────────────────────

  Future<List<Listing>> searchListings(String query) async {
    // 1. Fetch from the API (passing the search param just in case the backend fixes itself)
    final List<Listing> remoteResults =
        await _fetch(query.trim().isEmpty ? {} : {'search': query.trim()});

    if (query.trim().isEmpty) return remoteResults;

    // 2. SAFETY FILTER: If the backend returned everything, we filter it here
    final q = query.trim().toLowerCase();

    return remoteResults.where((listing) {
      final name = (listing.name ?? '').toLowerCase();
      final city = (listing.city ?? '').toLowerCase();
      final category = (listing.category ?? '').toLowerCase();

      return name.contains(q) || city.contains(q) || category.contains(q);
    }).toList();
  }

  // ── Create Booking ─────────────────────────────────────────────────────────

  Future<bool> createBooking({
    required String listingId,
    required String userId,
    required DateTime eventDate,
    required int guestCount,
    String? notes,
    double totalPrice = 0,
    double depositAmount = 0,
  }) async {
    final res = await http.post(
      Uri.parse('$_base/bookings'),
      headers: _headers,
      body: jsonEncode({
        'listingId': listingId,
        'eventDate': eventDate.toIso8601String(),
        'guestCount': guestCount,
        'depositAmount': 0, // tell backend nothing to collect
        'totalPrice': 0, // same
        'paymentStatus': 'paid', // mark as already paid
        'paymentMethod': 'cash', // cash = pay in person
        'status': 'pending', // try to skip pending_payment entirely
        if (notes != null && notes.trim().isNotEmpty)
          'specialRequests': notes.trim(),
      }),
    );

    if (res.statusCode != 200 && res.statusCode != 201) {
      final rb = jsonDecode(res.body) as Map<String, dynamic>;
      throw Exception(rb['message'] ?? 'Booking failed (${res.statusCode})');
    }

    // Also try confirm-payment after creation
    try {
      final rb = jsonDecode(res.body) as Map<String, dynamic>;
      final data = rb['data'] as Map<String, dynamic>? ?? rb;
      final bookingId = (data['_id'] ?? data['id'])?.toString() ?? '';
      if (bookingId.isNotEmpty) {
        await http.patch(
          Uri.parse('$_base/bookings/$bookingId/confirm-payment'),
          headers: _headers,
          body: jsonEncode({'paymentMethod': 'cash', 'paymentStatus': 'paid'}),
        );
      }
    } catch (_) {}

    return true;
  }

  // ── Get My Bookings ────────────────────────────────────────────────────────

  Future<List<UserBooking>> getMyBookings() async {
    final res = await http.get(
      Uri.parse('$_base/bookings'),
      headers: _headers,
    );
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200) {
      throw Exception(body['message'] ?? 'Failed to load bookings');
    }
    final data = body['data'] as List? ?? [];
    return data
        .map((e) => UserBooking.fromMap(e as Map<String, dynamic>))
        .toList();
  }

  // ── Chat helpers ───────────────────────────────────────────────────────────

  Future<void> sendMessage(String threadId, String content) async {
    await http.post(
      Uri.parse('$_base/chat/threads/$threadId/messages'),
      headers: _headers,
      body: jsonEncode({'content': content}),
    );
  }
}
