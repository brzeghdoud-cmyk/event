import 'package:flutter/material.dart';
import '../theme.dart';
// Import your screens here so the nav bar can route to them
import '../screens/home_screen.dart';
import '../screens/search_screen.dart';
import '../screens/chat_screen.dart';

class AppBottomNav extends StatelessWidget {
  final int currentIndex;
  final VoidCallback? onProfileTap; // For that cool profile bottom sheet

  const AppBottomNav({
    super.key,
    required this.currentIndex,
    this.onProfileTap,
  });

  void _handleNavigation(BuildContext context, int index) {
    // 1. If we're already here, don't do anything (prevents screen flickering)
    if (index == currentIndex) return;

    // 2. Profile Logic
    if (index == 3) {
      if (onProfileTap != null) onProfileTap!();
      return;
    }

    // 3. Define where to go
    Widget nextScreen;
    switch (index) {
      case 0:
        // When going Home, we clear the stack so the user doesn't get stuck in a loop
        Navigator.pushAndRemoveUntil(
          context,
          AppTheme.smoothRoute(const HomeScreen()),
          (route) => false,
        );
        return;
      case 1:
        nextScreen = const SearchScreen();
        break;
      case 2:
        nextScreen = const ChatListScreen();
        break;
      default:
        return;
    }

    // 4. THE TRANSFORM: Swap the current screen with the new one
    Navigator.pushReplacement(
      context,
      AppTheme.smoothRoute(nextScreen),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 0, 20, 24),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(32),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.12),
            blurRadius: 20,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _Item(
            icon: Icons.home_rounded,
            index: 0,
            current: currentIndex,
            onTap: (i) => _handleNavigation(context, i),
          ),
          _Item(
            icon: Icons.search_rounded,
            index: 1,
            current: currentIndex,
            onTap: (i) => _handleNavigation(context, i),
          ),
          _Item(
            icon: Icons.chat_bubble_outline_rounded,
            index: 2,
            current: currentIndex,
            onTap: (i) => _handleNavigation(context, i),
          ),
          _Item(
            icon: Icons.person_outline_rounded,
            index: 3,
            current: currentIndex,
            onTap: (i) => _handleNavigation(context, i),
          ),
        ],
      ),
    );
  }
}

class _Item extends StatelessWidget {
  final IconData icon;
  final int index, current;
  final ValueChanged<int> onTap;

  const _Item({
    required this.icon,
    required this.index,
    required this.current,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final active = index == current;
    return GestureDetector(
      onTap: () => onTap(index),
      behavior:
          HitTestBehavior.opaque, // Ensures the whole icon area is clickable
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOut,
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color:
              active ? AppTheme.primary.withOpacity(0.1) : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Icon(
          icon,
          color: active ? AppTheme.primary : AppTheme.textSecondary,
          size: 24,
        ),
      ),
    );
  }
}
