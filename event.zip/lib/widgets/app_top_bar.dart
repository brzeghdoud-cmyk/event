import 'package:flutter/material.dart';
import '../theme.dart';

class AppTopBar extends StatelessWidget implements PreferredSizeWidget {
  final VoidCallback? onBack;
  final VoidCallback? onProfile;

  const AppTopBar({super.key, this.onBack, this.onProfile});

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Colors.white,
      elevation: 0,
      leading: onBack != null
          ? IconButton(
              icon: const Icon(Icons.arrow_back_ios_rounded,
                  color: AppTheme.primary),
              onPressed: onBack,
            )
          : Padding(
              padding: const EdgeInsets.all(10),
              child: Transform.translate(
                offset: const Offset(4, -6),
                child: Image.asset(
                  'lib/assets/images/logo.png',
                  color: AppTheme.primary,
                  width: 22,
                  height: 22,
                ),
              ),
            ),
      title: const SizedBox.shrink(),
      centerTitle: true,
      actions: [
        IconButton(
          icon: Container(
            padding: const EdgeInsets.all(6),
            decoration:
                BoxDecoration(color: AppTheme.primary, shape: BoxShape.circle),
            child:
                const Icon(Icons.person_rounded, color: Colors.white, size: 20),
          ),
          onPressed: onProfile ?? () {},
        ),
        const SizedBox(width: 8),
      ],
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
