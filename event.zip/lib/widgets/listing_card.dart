import 'package:flutter/material.dart';
import '../models/listing.dart';
import '../theme.dart';

class ListingCard extends StatefulWidget {
  final Listing listing;
  final VoidCallback onTap;

  const ListingCard({super.key, required this.listing, required this.onTap});

  @override
  State<ListingCard> createState() => _ListingCardState();
}

class _ListingCardState extends State<ListingCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final l = widget.listing;
    return GestureDetector(
      onTap: widget.onTap,
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.cardBorder),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withOpacity(0.06),
                  blurRadius: 12,
                  offset: const Offset(0, 4)),
            ],
          ),
          child: Row(
            children: [
              ClipRRect(
                borderRadius:
                    const BorderRadius.horizontal(left: Radius.circular(16)),
                child: SizedBox(
                  width: 110,
                  height: 110,
                  child: l.imageUrls.isNotEmpty
                      ? Image.network(l.imageUrls.first,
                          fit: BoxFit.cover,
                          loadingBuilder: (_, child, p) {
                            if (p == null) return child;
                            return Container(
                                color: AppTheme.surface,
                                child: const Center(
                                    child: CircularProgressIndicator(
                                        color: AppTheme.primary,
                                        strokeWidth: 2)));
                          },
                          errorBuilder: (_, __, ___) => Container(
                              color: AppTheme.surface,
                              child: const Icon(Icons.image_not_supported,
                                  color: AppTheme.textSecondary)))
                      : Container(
                          color: AppTheme.surface,
                          child: const Icon(Icons.photo_library_outlined,
                              color: AppTheme.textSecondary, size: 32)),
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(children: [
                        if (l.isVerified)
                          const Padding(
                            padding: EdgeInsets.only(right: 4),
                            child: Icon(Icons.verified_rounded,
                                color: AppTheme.primary, size: 14),
                          ),
                        Expanded(
                          child: Text(l.name,
                              style: const TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 14,
                                  color: AppTheme.textPrimary),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis),
                        ),
                      ]),
                      const SizedBox(height: 4),
                      Text('${l.city}, ${l.wilaya} · up to ${l.capacityMax} guests',
                          style: const TextStyle(
                              fontSize: 12, color: AppTheme.textSecondary),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis),
                      if (l.has360Tour) ...[
                        const SizedBox(height: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                              color: Colors.green.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(4)),
                          child: const Text('360° Tour',
                              style: TextStyle(
                                  fontSize: 10,
                                  color: Colors.green,
                                  fontWeight: FontWeight.w600)),
                        ),
                      ],
                      const SizedBox(height: 6),
                      Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(l.formattedPrice,
                                style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                    color: AppTheme.priceColor)),
                            Row(children: [
                              const Icon(Icons.star_rounded,
                                  color: AppTheme.starColor, size: 16),
                              const SizedBox(width: 2),
                              Text(
                                  '${l.rating.toStringAsFixed(1)} (${l.reviewCount})',
                                  style: const TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600,
                                      color: AppTheme.textPrimary)),
                            ]),
                          ]),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
