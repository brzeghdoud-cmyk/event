import 'package:flutter/material.dart';

class Listing {
  final String id;
  final String name;
  final String city;
  final String wilaya;
  final String description;
  final String category;
  final double priceMin;
  final double priceMax;
  final String currency;
  final int capacityMin;
  final int capacityMax;
  final double rating;
  final int reviewCount;
  final List<String> imageUrls;
  final List<String> panoramaUrls;
  final double latitude;
  final double longitude;
  final bool isActive;
  final bool isVerified;
  final String? providerId;

  const Listing({
    required this.id,
    required this.name,
    required this.city,
    required this.wilaya,
    required this.description,
    required this.category,
    required this.priceMin,
    required this.priceMax,
    required this.currency,
    required this.capacityMin,
    required this.capacityMax,
    required this.rating,
    required this.reviewCount,
    required this.imageUrls,
    required this.panoramaUrls,
    required this.latitude,
    required this.longitude,
    required this.isActive,
    required this.isVerified,
    this.providerId,
  });

  factory Listing.fromMap(Map<String, dynamic> map) {
    final coords = (map['location']?['coordinates'] as List?) ?? [0, 0];
    final address = map['address'] as Map<String, dynamic>? ?? {};
    final price = map['priceRange'] as Map<String, dynamic>? ?? {};
    final cap = map['capacity'] as Map<String, dynamic>? ?? {};
    final provider = map['provider'];
    return Listing(
      id: map['id'] ?? map['_id'] ?? '',
      name: map['title'] ?? '',
      city: address['city'] ?? '',
      wilaya: address['wilaya'] ?? '',
      description: map['description'] ?? '',
      category: map['category'] ?? '',
      priceMin: (price['min'] as num?)?.toDouble() ?? 0,
      priceMax: (price['max'] as num?)?.toDouble() ?? 0,
      currency: price['currency'] ?? 'DZD',
      capacityMin: (cap['min'] as num?)?.toInt() ?? 0,
      capacityMax: (cap['max'] as num?)?.toInt() ?? 0,
      rating: (map['rating'] as num?)?.toDouble() ?? 0,
      reviewCount: (map['reviewCount'] as num?)?.toInt() ?? 0,
      imageUrls: List<String>.from(map['imageUrls'] ?? []),
      panoramaUrls: List<String>.from(map['panoramaUrls'] ?? []),
      longitude: (coords[0] as num).toDouble(),
      latitude: (coords[1] as num).toDouble(),
      isActive: map['isActive'] ?? true,
      isVerified: map['isVerified'] ?? false,
      providerId: provider is Map
          ? (provider['_id'] ?? provider['id'])
          : (provider?.toString()),
    );
  }

  String get formattedPrice {
    final n = priceMin.toStringAsFixed(0).replaceAllMapped(
        RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]} ');
    return '$n $currency';
  }

  int get capacity => capacityMax;
  bool get has360Tour => panoramaUrls.isNotEmpty;
}

class Booking {
  final String id;
  final String listingId;
  final String listingTitle;
  final String status;
  final DateTime eventDate;
  final int guestCount;
  final double totalPrice;
  final DateTime createdAt;

  const Booking({
    required this.id,
    required this.listingId,
    required this.listingTitle,
    required this.status,
    required this.eventDate,
    required this.guestCount,
    required this.totalPrice,
    required this.createdAt,
  });

  factory Booking.fromMap(Map<String, dynamic> map) {
    final listing = map['listing'] as Map<String, dynamic>? ?? {};
    return Booking(
      id: map['_id'] ?? map['id'] ?? '',
      listingId: listing['_id'] ?? listing['id'] ?? '',
      listingTitle: listing['title'] ?? '',
      status: map['status'] ?? 'pending_payment',
      eventDate: DateTime.tryParse(map['eventDate'] ?? '') ?? DateTime.now(),
      guestCount: (map['guestCount'] as num?)?.toInt() ?? 0,
      totalPrice: (map['totalPrice'] as num?)?.toDouble() ?? 0,
      createdAt: DateTime.tryParse(map['createdAt'] ?? '') ?? DateTime.now(),
    );
  }

  String get statusLabel {
    switch (status) {
      case 'pending_payment':
        return 'Pending';
      case 'in_progress':
        return 'In Progress';
      default:
        return '${status[0].toUpperCase()}${status.substring(1)}';
    }
  }

  Color get statusColor {
    switch (status) {
      case 'confirmed':
        return const Color(0xFF43A047);
      case 'cancelled':
        return const Color(0xFFE53935);
      case 'completed':
        return const Color(0xFF1E88E5);
      default:
        return const Color(0xFFFFB800);
    }
  }
}
