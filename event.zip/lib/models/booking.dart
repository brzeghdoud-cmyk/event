import 'package:flutter/material.dart';

class UserBooking {
  final String id;
  final String listingId;
  final String listingTitle;
  final String? listingImageUrl;
  final String? listingCity;
  final String? listingWilaya;
  final String? providerId;
  final String? providerName;
  final String? chatThreadId;
  final DateTime eventDate;
  final int guestCount;
  final String status;
  final double totalPrice;
  final String? specialRequests;
  final DateTime createdAt;

  const UserBooking({
    required this.id,
    required this.listingId,
    required this.listingTitle,
    this.listingImageUrl,
    this.listingCity,
    this.listingWilaya,
    this.providerId,
    this.providerName,
    this.chatThreadId,
    required this.eventDate,
    required this.guestCount,
    required this.status,
    required this.totalPrice,
    this.specialRequests,
    required this.createdAt,
  });

  factory UserBooking.fromMap(Map<String, dynamic> map) {
    final listing = map['listing'] as Map<String, dynamic>? ?? {};
    final address = listing['address'] as Map<String, dynamic>? ?? {};
    final provider = listing['provider'] as Map<String, dynamic>? ?? {};

    return UserBooking(
      id: map['_id'] ?? map['id'] ?? '',
      listingId:
          listing['_id'] ?? listing['id'] ?? map['listing']?.toString() ?? '',
      listingTitle: listing['title'] ?? '',
      listingImageUrl: (listing['imageUrls'] as List?)?.isNotEmpty == true
          ? (listing['imageUrls'] as List).first as String
          : null,
      listingCity: address['city'],
      listingWilaya: address['wilaya'],
      providerId: provider['_id'] ?? provider['id'],
      providerName: provider.isNotEmpty
          ? '${provider['firstName'] ?? ''} ${provider['lastName'] ?? ''}'
              .trim()
          : null,
      chatThreadId: map['chatThreadId'],
      eventDate: DateTime.tryParse(map['eventDate'] ?? '') ?? DateTime.now(),
      guestCount: (map['guestCount'] as num?)?.toInt() ?? 0,
      status: _normalise(map['status'] ?? 'pending_payment'),
      totalPrice: (map['totalPrice'] as num?)?.toDouble() ?? 0,
      specialRequests: map['specialRequests'],
      createdAt: DateTime.tryParse(map['createdAt'] ?? '') ?? DateTime.now(),
    );
  }

  static String _normalise(String s) {
    switch (s) {
      case 'pending_payment':
      case 'in_progress':
        return 'pending';
      default:
        return s;
    }
  }

  String get statusLabel {
    switch (status) {
      case 'pending':
        return 'Awaiting Confirmation';
      case 'confirmed':
        return 'Confirmed ✓';
      case 'cancelled':
        return 'Cancelled';
      case 'completed':
        return 'Completed';
      case 'disputed':
        return 'Disputed';
      default:
        return '${status[0].toUpperCase()}${status.substring(1)}';
    }
  }

  Color get statusColor {
    switch (status) {
      case 'confirmed':
        return const Color(0xFF43A047);
      case 'cancelled':
        return const Color(0xFFE53935);
      case 'completed':
        return const Color(0xFF1E88E5);
      case 'disputed':
        return const Color(0xFFFF6F00);
      default:
        return const Color(0xFFFFB800);
    }
  }

  String get formattedDate =>
      '${eventDate.day}/${eventDate.month}/${eventDate.year}';
  String get formattedPrice => '${totalPrice.toInt()} DZD';
}
