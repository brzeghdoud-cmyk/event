// models.dart
import 'package:flutter/material.dart';

class AuthUser {
  final String id;
  final String email;
  final String firstName;
  final String lastName;
  final String role;
  final String? phone;
  final String? avatarUrl;
  final bool isVerified;
  final String accessToken;
  final String refreshToken;

  const AuthUser({
    required this.id,
    required this.email,
    required this.firstName,
    required this.lastName,
    required this.role,
    this.phone,
    this.avatarUrl,
    required this.isVerified,
    required this.accessToken,
    required this.refreshToken,
  });

  String get fullName => '$firstName $lastName';
  String get initials =>
      '${firstName.isNotEmpty ? firstName[0] : ''}${lastName.isNotEmpty ? lastName[0] : ''}'
          .toUpperCase();

  factory AuthUser.fromMap(
          Map<String, dynamic> map, String access, String refresh) =>
      AuthUser(
        id: map['_id'] ?? map['id'] ?? '',
        email: map['email'] ?? '',
        firstName: map['firstName'] ?? '',
        lastName: map['lastName'] ?? '',
        role: map['role'] ?? 'provider',
        phone: map['phone'],
        avatarUrl: map['avatarUrl'],
        isVerified: map['isVerified'] ?? false,
        accessToken: access,
        refreshToken: refresh,
      );
}

class ProviderListing {
  final String? id;
  final String? providerId;
  final String title, description, category, city, wilaya;
  final double priceMin, priceMax, rating;
  final int capacityMin, capacityMax, reviewCount;
  final List<String> imageUrls, amenities;
  final bool isActive, isVerified;

  const ProviderListing({
    this.id,
    this.providerId,
    required this.title,
    required this.description,
    required this.category,
    required this.priceMin,
    required this.priceMax,
    required this.capacityMin,
    required this.capacityMax,
    required this.city,
    required this.wilaya,
    required this.imageUrls,
    required this.amenities,
    this.rating = 0,
    this.reviewCount = 0,
    this.isActive = true,
    this.isVerified = false,
  });

  factory ProviderListing.fromMap(Map<String, dynamic> map) {
    // Helper to clean MongoDB IDs
    String? cleanId(dynamic val) {
      if (val is Map && val.containsKey('\$oid')) {
        return val['\$oid']?.toString();
      }
      return val?.toString();
    }

    final price = map['priceRange'] as Map<String, dynamic>? ?? {};
    final cap = map['capacity'] as Map<String, dynamic>? ?? {};
    final address = map['address'] as Map<String, dynamic>? ?? {};

    return ProviderListing(
      id: cleanId(map['_id'] ?? map['id']),
      providerId: cleanId(map['provider']),
      title: map['title'] ?? '',
      description: map['description'] ?? '',
      category: map['category'] ?? '',
      priceMin: (price['min'] as num?)?.toDouble() ?? 0,
      priceMax: (price['max'] as num?)?.toDouble() ?? 0,
      capacityMin: (cap['min'] as num?)?.toInt() ?? 0,
      capacityMax: (cap['max'] as num?)?.toInt() ?? 0,
      city: address['city'] ?? '',
      wilaya: address['wilaya'] ?? '',
      imageUrls: List<String>.from(map['imageUrls'] ?? []),
      amenities: List<String>.from(map['amenities'] ?? []),
      rating: (map['rating'] as num?)?.toDouble() ?? 0,
      reviewCount: (map['reviewCount'] as num?)?.toInt() ?? 0,
      isActive: map['isActive'] ?? true,
      isVerified: map['isVerified'] ?? false,
    );
  }

  Map<String, dynamic> toCreateMap() => {
        'title': title,
        'description': description,
        'category': category,
        'priceRange': {'min': priceMin, 'max': priceMax, 'currency': 'DZD'},
        'capacity': {'min': capacityMin, 'max': capacityMax},
        'address': {'city': city, 'wilaya': wilaya},
        'imageUrls': imageUrls,
        'amenities': amenities,
        'location': {
          'type': 'Point',
          'coordinates': [3.261196, 36.7723308]
        },
      };

  String get formattedPrice => '${priceMin.toInt()} – ${priceMax.toInt()} DZD';
}

class Booking {
  final String id, listingId, listingTitle, clientId, clientName, clientEmail;
  final String? clientPhone, specialRequests;
  final DateTime eventDate, createdAt;
  final int guestCount;
  final String status;
  final double totalPrice;

  const Booking({
    required this.id,
    required this.listingId,
    required this.listingTitle,
    required this.clientId,
    required this.clientName,
    required this.clientEmail,
    this.clientPhone,
    required this.eventDate,
    required this.guestCount,
    required this.status,
    required this.totalPrice,
    this.specialRequests,
    required this.createdAt,
  });

  factory Booking.fromMap(Map<String, dynamic> map) {
    final client = map['client'] as Map<String, dynamic>? ?? {};
    final listing = map['listing'] as Map<String, dynamic>? ?? {};
    return Booking(
      id: _cleanId(map['_id'] ?? map['id']) ?? '',
      listingId: listing['_id'] ?? listing['id'] ?? '',
      listingTitle: listing['title'] ?? '',
      clientId: client['_id'] ?? client['id'] ?? '',
      clientName:
          '${client['firstName'] ?? ''} ${client['lastName'] ?? ''}'.trim(),
      clientEmail: client['email'] ?? '',
      clientPhone: client['phone'],
      eventDate: DateTime.tryParse(map['eventDate'] ?? '') ?? DateTime.now(),
      guestCount: (map['guestCount'] as num?)?.toInt() ?? 0,
      status: map['status'] ?? 'pending_payment',
      totalPrice: (map['totalPrice'] as num?)?.toDouble() ?? 0,
      specialRequests: map['specialRequests'],
      createdAt: DateTime.tryParse(map['createdAt'] ?? '') ?? DateTime.now(),
    );
  }

  Color get statusColor {
    switch (status) {
      case 'confirmed':
        return const Color(0xFF43A047);
      case 'cancelled':
        return const Color(0xFFE53935);
      case 'completed':
        return const Color(0xFF1E88E5);
      case 'in_progress':
        return const Color(0xFF8B00CC);
      case 'disputed':
        return const Color(0xFFFF6F00);
      default:
        return const Color(0xFFFFB800);
    }
  }

  String get statusLabel {
    switch (status) {
      case 'pending_payment':
        return 'Pending';
      case 'in_progress':
        return 'In Progress';
      default:
        return '${status[0].toUpperCase()}${status.substring(1)}';
    }
  }
}

class ChatThread {
  final String id, otherUserId, otherUserName, lastMessage;
  final String? otherUserAvatar, listingId, listingTitle;
  final DateTime lastMessageAt;
  final int unreadCount;

  const ChatThread({
    required this.id,
    required this.otherUserId,
    required this.otherUserName,
    this.otherUserAvatar,
    this.listingId,
    this.listingTitle,
    required this.lastMessage,
    required this.lastMessageAt,
    required this.unreadCount,
  });

  factory ChatThread.fromMap(Map<String, dynamic> map, String myId) {
    final rawParts = map['participants'] as List? ?? [];

    // participants can be populated objects OR plain ID strings
    final parts = rawParts.map((p) {
      if (p is Map) return Map<String, dynamic>.from(p);
      return <String, dynamic>{'_id': p.toString()};
    }).toList();

    final other = parts.firstWhere(
      (p) => (p['_id'] ?? p['id'] ?? '').toString() != myId,
      orElse: () => parts.isNotEmpty ? parts.first : <String, dynamic>{},
    );

    final rawListing = map['listing'];
    final listing =
        rawListing is Map ? Map<String, dynamic>.from(rawListing) : null;

    // unreadCount is a Map<userId, count> on backend
    int unread = 0;
    final uc = map['unreadCount'];
    if (uc is Map) {
      unread = (uc[myId] as num?)?.toInt() ?? 0;
    }

    return ChatThread(
      id: (map['_id'] ?? map['id'] ?? '').toString(),
      otherUserId: (other['_id'] ?? other['id'] ?? '').toString(),
      otherUserName:
          '${other['firstName'] ?? ''} ${other['lastName'] ?? ''}'.trim(),
      otherUserAvatar: other['avatarUrl'],
      listingId: listing?['_id']?.toString() ?? listing?['id']?.toString(),
      listingTitle: listing?['title'],
      lastMessage: (map['lastMessage'] ?? '').toString(),
      lastMessageAt:
          DateTime.tryParse(map['lastMessageAt'] ?? map['updatedAt'] ?? '') ??
              DateTime.now(),
      unreadCount: unread,
    );
  }
}

class ChatMessage {
  final String id, senderId, content, type;
  final DateTime createdAt;
  final bool isMe;

  const ChatMessage({
    required this.id,
    required this.senderId,
    required this.content,
    required this.type,
    required this.createdAt,
    required this.isMe,
  });

  factory ChatMessage.fromMap(Map<String, dynamic> map, String myId) {
    final sender = map['sender'];
    final sid =
        sender is Map ? (sender['_id'] ?? sender['id'] ?? '') : (sender ?? '');
    return ChatMessage(
      id: map['_id'] ?? map['id'] ?? '',
      senderId: sid.toString(),
      content: map['content'] ?? '',
      type: map['type'] ?? 'text',
      createdAt: DateTime.tryParse(map['createdAt'] ?? '') ?? DateTime.now(),
      isMe: sid.toString() == myId,
    );
  }
}

String? _cleanId(dynamic val) {
  if (val == null) return null;
  if (val is Map && val.containsKey('\$oid')) return val['\$oid']?.toString();
  return val.toString();
}
