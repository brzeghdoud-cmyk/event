// api_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/models.dart';

class ApiService {
  static final ApiService instance = ApiService._();
  ApiService._();

  static const String _base = 'https://eventrepo-yn7f.onrender.com/api/v1';

  String? _accessToken;
  String? _refreshToken;
  String? _userId;

  String? get userId => _userId;

  Map<String, String> get headers => {
        'Content-Type': 'application/json',
        if (_accessToken != null) 'Authorization': 'Bearer $_accessToken',
      };

  Future<void> _save(String access, String refresh, String uid) async {
    _accessToken = access;
    _refreshToken = refresh;
    _userId = uid;
    final p = await SharedPreferences.getInstance();
    await p.setString('biz_access', access);
    await p.setString('biz_refresh', refresh);
    await p.setString('biz_uid', uid);
  }

  Future<bool> restoreSession() async {
    final p = await SharedPreferences.getInstance();
    _accessToken = p.getString('biz_access');
    _refreshToken = p.getString('biz_refresh');
    _userId = p.getString('biz_uid');
    if (_accessToken == null) return false;
    try {
      final res =
          await http.get(Uri.parse('$_base/users/me'), headers: headers);
      return res.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  Future<void> clearSession() async {
    _accessToken = null;
    _refreshToken = null;
    _userId = null;
    final p = await SharedPreferences.getInstance();
    await p.remove('biz_access');
    await p.remove('biz_refresh');
    await p.remove('biz_uid');
  }

  Future<AuthUser> register({
    required String email,
    required String password,
    required String firstName,
    required String lastName,
    required String phone,
  }) async {
    final res = await http.post(Uri.parse('$_base/auth/register'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'email': email.trim().toLowerCase(),
          'password': password,
          'firstName': firstName.trim(),
          'lastName': lastName.trim(),
          'phone': phone.trim(),
          'role': 'provider',
        }));
    return _handleAuth(res);
  }

  Future<AuthUser> login(String email, String password) async {
    final res = await http.post(Uri.parse('$_base/auth/login'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(
            {'email': email.trim().toLowerCase(), 'password': password}));
    return _handleAuth(res);
  }

  Future<void> logout() async {
    try {
      await http.post(Uri.parse('$_base/auth/logout'),
          headers: headers,
          body: jsonEncode({'refreshToken': _refreshToken ?? ''}));
    } catch (_) {}
    await clearSession();
  }

  Future<AuthUser> _handleAuth(http.Response res) async {
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200 && res.statusCode != 201) {
      throw Exception(body['message'] ?? 'Auth failed');
    }
    final data = body['data'] as Map<String, dynamic>? ?? body;
    final access = data['accessToken'] ?? data['token'] ?? '';
    final refresh = data['refreshToken'] ?? '';
    final userMap = data['user'] as Map<String, dynamic>? ?? data;
    final user = AuthUser.fromMap(userMap, access, refresh);
    await _save(access, refresh, user.id);
    return user;
  }

  Future<AuthUser> getMe() async {
    final res = await http.get(Uri.parse('$_base/users/me'), headers: headers);
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200) throw Exception(body['message'] ?? 'Failed');
    final data = body['data'] as Map<String, dynamic>? ?? body;
    return AuthUser.fromMap(data, _accessToken ?? '', _refreshToken ?? '');
  }

  Future<void> updatePassword(String current, String next) async {
    final res = await http.patch(Uri.parse('$_base/users/me/password'),
        headers: headers,
        body: jsonEncode({'currentPassword': current, 'newPassword': next}));
    if (res.statusCode != 200) {
      final body = jsonDecode(res.body) as Map<String, dynamic>;
      throw Exception(body['message'] ?? 'Failed');
    }
  }

  // Listings
  // Replace the whole getMyListings with:
  Future<List<ProviderListing>> getMyListings() async {
    final res = await http.get(
      Uri.parse('$_base/listings?provider=$_userId'),
      headers: headers,
    );
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200) throw Exception(body['message'] ?? 'Failed');

    final raw = body['data'] as List? ?? [];

    // Filter directly on raw map before parsing — catches all ID formats
    final mine = raw.where((e) {
      final map = e as Map<String, dynamic>;
      final provider = map['provider'];
      if (provider == null) return false;
      if (provider is String) return provider == _userId;
      if (provider is Map) {
        final pid = (provider['_id'] ?? provider['id'] ?? '').toString();
        return pid == _userId;
      }
      return false;
    }).toList();

    return mine
        .map((e) => ProviderListing.fromMap(e as Map<String, dynamic>))
        .toList();
  }

  Future<ProviderListing> createListing(ProviderListing l) async {
    final res = await http.post(Uri.parse('$_base/listings'),
        headers: headers, body: jsonEncode(l.toCreateMap()));
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200 && res.statusCode != 201)
      throw Exception(body['message'] ?? 'Failed');
    return ProviderListing.fromMap(
        body['data'] as Map<String, dynamic>? ?? body);
  }

  Future<ProviderListing> updateListing(String id, ProviderListing l) async {
    final res = await http.patch(Uri.parse('$_base/listings/$id'),
        headers: headers, body: jsonEncode(l.toCreateMap()));
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200) throw Exception(body['message'] ?? 'Failed');
    return ProviderListing.fromMap(
        body['data'] as Map<String, dynamic>? ?? body);
  }

  Future<void> deleteListing(String id) async {
    final res =
        await http.delete(Uri.parse('$_base/listings/$id'), headers: headers);
    if (res.statusCode != 200 && res.statusCode != 204) {
      final body = jsonDecode(res.body) as Map<String, dynamic>;
      throw Exception(body['message'] ?? 'Failed');
    }
  }

  // Bookings
  Future<List<Booking>> getMyBookings() async {
    final res = await http.get(Uri.parse('$_base/bookings'), headers: headers);
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200) throw Exception(body['message'] ?? 'Failed');

    final raw = body['data'] as List? ?? [];

    // Filter to only bookings where provider matches logged-in user
    final mine = raw.where((e) {
      final map = e as Map<String, dynamic>;
      final provider = map['provider'];
      if (provider == null) return false;
      if (provider is String) return provider == _userId;
      if (provider is Map) {
        final pid = (provider['_id'] ?? provider['id'] ?? '').toString();
        return pid == _userId;
      }
      return false;
    }).toList();

    return mine.map((e) => Booking.fromMap(e as Map<String, dynamic>)).toList();
  }

  Future<void> acceptBooking(String id) async {
    final res = await http.patch(Uri.parse('$_base/bookings/$id/accept'),
        headers: headers, body: jsonEncode({}));
    if (res.statusCode != 200) {
      final body = jsonDecode(res.body) as Map<String, dynamic>;
      throw Exception(body['message'] ?? 'Failed');
    }
  }

  Future<void> rejectBooking(String id, String reason) async {
    final res = await http.patch(Uri.parse('$_base/bookings/$id/reject'),
        headers: headers, body: jsonEncode({'reason': reason}));
    if (res.statusCode != 200) {
      final body = jsonDecode(res.body) as Map<String, dynamic>;
      throw Exception(body['message'] ?? 'Failed');
    }
  }

  Future<void> completeBooking(String id) async {
    final res = await http.patch(Uri.parse('$_base/bookings/$id/complete'),
        headers: headers, body: jsonEncode({}));
    if (res.statusCode != 200) {
      final body = jsonDecode(res.body) as Map<String, dynamic>;
      throw Exception(body['message'] ?? 'Failed');
    }
  }

  // Chat
  Future<List<ChatThread>> getThreads() async {
    final res =
        await http.get(Uri.parse('$_base/chat/threads'), headers: headers);
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200) throw Exception(body['message'] ?? 'Failed');
    final raw = body['data'] as List? ?? [];
    // parse safely — skip any thread that fails to parse
    final threads = <ChatThread>[];
    for (final e in raw) {
      try {
        threads
            .add(ChatThread.fromMap(e as Map<String, dynamic>, _userId ?? ''));
      } catch (_) {}
    }
    return threads;
  }

  Future<List<ChatMessage>> getMessages(String threadId) async {
    final res = await http.get(
        Uri.parse('$_base/chat/threads/$threadId/messages'),
        headers: headers);
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200) throw Exception(body['message'] ?? 'Failed');
    final msgs = (body['data'] as List? ?? [])
        .map((e) =>
            ChatMessage.fromMap(e as Map<String, dynamic>, _userId ?? ''))
        .toList();
    // backend returns newest-first, sort so oldest is first (bottom = newest)
    msgs.sort((a, b) => a.createdAt.compareTo(b.createdAt));
    return msgs;
  }

  Future<ChatMessage> sendMessage(String threadId, String content) async {
    final res = await http.post(
        Uri.parse('$_base/chat/threads/$threadId/messages'),
        headers: headers,
        body: jsonEncode({'content': content}));
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200 && res.statusCode != 201) {
      throw Exception(body['message'] ?? 'Failed');
    }
    // backend returns { data: { message: {...} } }
    final data = body['data'] as Map<String, dynamic>? ?? {};
    final msgMap = data['message'] as Map<String, dynamic>? ?? data;
    return ChatMessage.fromMap(msgMap, _userId ?? '');
  }

  Future<void> markRead(String threadId) async {
    await http.patch(Uri.parse('$_base/chat/threads/$threadId/read'),
        headers: headers);
  }

  Future<ChatThread> createThread(
      String participantId, String listingId) async {
    final res = await http.post(Uri.parse('$_base/chat/threads'),
        headers: headers,
        body: jsonEncode({
          'recipientId': participantId, //
          'listingId': listingId,
        }));
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200 && res.statusCode != 201) {
      throw Exception(body['message'] ?? 'Failed');
    }
    // backend returns { data: { thread: {...} } }
    final data = body['data'] as Map<String, dynamic>? ?? {};
    final threadMap = data['thread'] as Map<String, dynamic>? ?? data;
    return ChatThread.fromMap(threadMap, _userId ?? '');
  }
}
