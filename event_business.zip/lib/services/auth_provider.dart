import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/api_service.dart';

class AuthProvider extends ChangeNotifier {
  AuthUser? _user;
  bool _loading = true;

  AuthUser? get user => _user;
  bool get isLoading => _loading;
  bool get isLoggedIn => _user != null;

  Future<void> init() async {
    final ok = await ApiService.instance.restoreSession();
    if (ok) {
      try { _user = await ApiService.instance.getMe(); }
      catch (_) { await ApiService.instance.clearSession(); }
    }
    _loading = false;
    notifyListeners();
  }

  Future<void> login(String email, String password) async {
    _user = await ApiService.instance.login(email, password);
    notifyListeners();
  }

  Future<void> register({
    required String email, required String password,
    required String firstName, required String lastName, required String phone,
  }) async {
    _user = await ApiService.instance.register(
      email: email, password: password,
      firstName: firstName, lastName: lastName, phone: phone,
    );
    notifyListeners();
  }

  Future<void> logout() async {
    await ApiService.instance.logout();
    _user = null;
    notifyListeners();
  }
}
