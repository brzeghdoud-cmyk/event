import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import '../theme.dart';
import '../widgets/shared_widgets.dart';
import 'dart:io'; // To handle local files
import 'package:image_picker/image_picker.dart'; // For gallery/camera access
import 'dart:convert';

class ListingsScreen extends StatefulWidget {
  const ListingsScreen({super.key});

  @override
  State<ListingsScreen> createState() => _ListingsScreenState();
}

class _ListingsScreenState extends State<ListingsScreen> {
  List<ProviderListing> _listings = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final data = await ApiService.instance.getMyListings();
      if (mounted)
        setState(() {
          _listings = data;
          _loading = false;
        });
    } catch (e) {
      if (mounted)
        setState(() {
          _error = e.toString().replaceAll('Exception: ', '');
          _loading = false;
        });
    }
  }

  Future<void> _delete(ProviderListing l) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Delete Listing',
            style: TextStyle(fontWeight: FontWeight.w800)),
        content: Text('Delete "${l.title}"? This cannot be undone.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.error),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await ApiService.instance.deleteListing(l.id!);
      _load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(e.toString().replaceAll('Exception: ', ''))));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppTopBar(
        title: 'My Listings',
        actions: [
          IconButton(
            icon: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                  color: AppTheme.primary,
                  borderRadius: BorderRadius.circular(10)),
              child:
                  const Icon(Icons.add_rounded, color: Colors.white, size: 20),
            ),
            onPressed: () async {
              await Navigator.push(
                  context, AppTheme.smoothRoute(const AddEditListingScreen()));
              _load();
            },
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: AppTheme.primary))
          : _error != null
              ? Center(
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                      const Icon(Icons.wifi_off_rounded,
                          size: 48, color: AppTheme.textSecondary),
                      const SizedBox(height: 12),
                      Text(_error!,
                          textAlign: TextAlign.center,
                          style:
                              const TextStyle(color: AppTheme.textSecondary)),
                      const SizedBox(height: 16),
                      ElevatedButton.icon(
                          onPressed: _load,
                          icon: const Icon(Icons.refresh_rounded),
                          label: const Text('Retry')),
                    ]))
              : _listings.isEmpty
                  ? Center(
                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                          const Icon(Icons.storefront_outlined,
                              size: 56, color: AppTheme.textSecondary),
                          const SizedBox(height: 14),
                          const Text('No listings yet',
                              style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 16,
                                  color: AppTheme.textPrimary)),
                          const SizedBox(height: 6),
                          const Text('Tap + to add your first listing',
                              style: TextStyle(color: AppTheme.textSecondary)),
                          const SizedBox(height: 20),
                          ElevatedButton.icon(
                            onPressed: () async {
                              await Navigator.push(
                                  context,
                                  AppTheme.smoothRoute(
                                      const AddEditListingScreen()));
                              _load();
                            },
                            icon: const Icon(Icons.add_rounded),
                            label: const Text('Add Listing'),
                          ),
                        ]))
                  : RefreshIndicator(
                      color: AppTheme.primary,
                      onRefresh: _load,
                      child: ListView.builder(
                        physics: const BouncingScrollPhysics(
                            parent: AlwaysScrollableScrollPhysics()),
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
                        itemCount: _listings.length,
                        itemBuilder: (_, i) => _ListingCard(
                          listing: _listings[i],
                          onEdit: () async {
                            await Navigator.push(
                                context,
                                AppTheme.smoothRoute(AddEditListingScreen(
                                    existing: _listings[i])));
                            _load();
                          },
                          onDelete: () => _delete(_listings[i]),
                        ),
                      ),
                    ),
    );
  }
}

class _ListingCard extends StatelessWidget {
  final ProviderListing listing;
  final VoidCallback onEdit, onDelete;
  const _ListingCard(
      {required this.listing, required this.onEdit, required this.onDelete});

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppTheme.cardBorder),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 10,
                offset: const Offset(0, 3))
          ],
        ),
        child: Column(children: [
          Row(children: [
            ClipRRect(
              borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(16),
                  bottomLeft: Radius.circular(16)),
              child: SizedBox(
                width: 90,
                height: 90,
                child: listing.imageUrls.isNotEmpty
                    ? (listing.imageUrls.first.startsWith('data:image/')
                        ? Image.memory(
                            base64Decode(listing.imageUrls.first.split(',')[1]),
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) =>
                                Container(
                                    color: AppTheme.surface,
                                    child: const Icon(Icons.image_not_supported,
                                        color: AppTheme.textSecondary)),
                          )
                        : Image.network(listing.imageUrls.first,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) =>
                                Container(
                                    color: AppTheme.surface,
                                    child: const Icon(Icons.image_not_supported,
                                        color: AppTheme.textSecondary))))
                    : Container(
                        color: AppTheme.surface,
                        child: const Icon(Icons.photo_library_outlined,
                            color: AppTheme.textSecondary)),
              ),
            ),
            Expanded(
                child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      Expanded(
                          child: Text(listing.title,
                              style: const TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 14,
                                  color: AppTheme.textPrimary),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis)),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 7, vertical: 3),
                        decoration: BoxDecoration(
                          color: listing.isActive
                              ? AppTheme.success.withOpacity(0.1)
                              : AppTheme.error.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(listing.isActive ? 'Active' : 'Inactive',
                            style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w700,
                                color: listing.isActive
                                    ? AppTheme.success
                                    : AppTheme.error)),
                      ),
                    ]),
                    const SizedBox(height: 4),
                    Text('${listing.city}, ${listing.wilaya}',
                        style: const TextStyle(
                            fontSize: 12, color: AppTheme.textSecondary)),
                    const SizedBox(height: 4),
                    Text(listing.formattedPrice,
                        style: const TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: AppTheme.primary)),
                    if (listing.rating > 0)
                      Row(children: [
                        const Icon(Icons.star_rounded,
                            size: 13, color: AppTheme.warning),
                        const SizedBox(width: 3),
                        Text(
                            '${listing.rating.toStringAsFixed(1)} (${listing.reviewCount})',
                            style: const TextStyle(
                                fontSize: 11, color: AppTheme.textSecondary)),
                      ]),
                  ]),
            )),
            Column(children: [
              IconButton(
                  icon: const Icon(Icons.edit_outlined,
                      color: AppTheme.primary, size: 20),
                  onPressed: onEdit),
              IconButton(
                  icon: const Icon(Icons.delete_outline,
                      color: AppTheme.error, size: 20),
                  onPressed: onDelete),
            ]),
          ]),
          if (listing.isVerified)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 6),
              decoration: BoxDecoration(
                color: AppTheme.success.withOpacity(0.08),
                borderRadius:
                    const BorderRadius.vertical(bottom: Radius.circular(16)),
              ),
              child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.verified_rounded,
                        size: 13, color: AppTheme.success),
                    SizedBox(width: 4),
                    Text('Verified by admin',
                        style: TextStyle(
                            fontSize: 11,
                            color: AppTheme.success,
                            fontWeight: FontWeight.w600)),
                  ]),
            ),
        ]),
      );
}

// ── Add / Edit ────────────────────────────────────────────────────────────────

class AddEditListingScreen extends StatefulWidget {
  final ProviderListing? existing;
  const AddEditListingScreen({super.key, this.existing});

  @override
  State<AddEditListingScreen> createState() => _AddEditState();
}

class _AddEditState extends State<AddEditListingScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  final _cityCtrl = TextEditingController();
  final _wilayaCtrl = TextEditingController();
  final _priceMinCtrl = TextEditingController();
  final _priceMaxCtrl = TextEditingController();
  final _capMinCtrl = TextEditingController();
  final _capMaxCtrl = TextEditingController();
  final _imgCtrl = TextEditingController();
  final _amenityCtrl = TextEditingController();
  final ImagePicker _picker = ImagePicker();

  String _category = 'venue';
  List<String> _images = [];
  List<String> _amenities = [];

  bool _loading = false;
  String? _error;

  final _cats = [
    'venue',
    'photographer',
    'dj',
    'caterer',
    'decorator',
    'other'
  ];
  bool get _isEdit => widget.existing != null;

  @override
  void initState() {
    super.initState();
    if (_isEdit) {
      final e = widget.existing!;
      _titleCtrl.text = e.title;
      _descCtrl.text = e.description;
      _cityCtrl.text = e.city;
      _wilayaCtrl.text = e.wilaya;
      _priceMinCtrl.text = e.priceMin.toInt().toString();
      _priceMaxCtrl.text = e.priceMax.toInt().toString();
      _capMinCtrl.text = e.capacityMin.toString();
      _capMaxCtrl.text = e.capacityMax.toString();
      _category = e.category;
      _images = List.from(e.imageUrls);
      _amenities = List.from(e.amenities);
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    final l = ProviderListing(
      title: _titleCtrl.text.trim(),
      description: _descCtrl.text.trim(),
      category: _category,
      priceMin: double.tryParse(_priceMinCtrl.text) ?? 0,
      priceMax: double.tryParse(_priceMaxCtrl.text) ?? 0,
      capacityMin: int.tryParse(_capMinCtrl.text) ?? 0,
      capacityMax: int.tryParse(_capMaxCtrl.text) ?? 0,
      city: _cityCtrl.text.trim(),
      wilaya: _wilayaCtrl.text.trim(),
      imageUrls: _images,
      amenities: _amenities,
    );
    try {
      if (_isEdit) {
        await ApiService.instance.updateListing(widget.existing!.id!, l);
      } else {
        await ApiService.instance.createListing(l);
      }
      if (mounted) Navigator.pop(context);
    } catch (e) {
      setState(() => _error = e.toString().replaceAll('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _descCtrl.dispose();
    _cityCtrl.dispose();
    _wilayaCtrl.dispose();
    _priceMinCtrl.dispose();
    _priceMaxCtrl.dispose();
    _capMinCtrl.dispose();
    _capMaxCtrl.dispose();
    _imgCtrl.dispose();
    _amenityCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickImage(ImageSource source) async {
    final XFile? pickedFile = await _picker.pickImage(
      source: source,
      imageQuality: 25, // Lowered from 50 to 25
      maxWidth: 400, // Lowered from 800 to 400 pixels
      maxHeight: 400,
    );

    if (pickedFile != null) {
      final bytes = await pickedFile.readAsBytes();
      final String base64Image = base64Encode(bytes);

      setState(() {
        // We add a "data" prefix so the Image widget knows it's not a URL
        _images.add("data:image/jpeg;base64,$base64Image");
      });
    }
  }

  void _showPicker() {
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('Gallery'),
              onTap: () {
                _pickImage(ImageSource.gallery);
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.camera_alt),
              title: const Text('Camera'),
              onTap: () {
                _pickImage(ImageSource.camera);
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppTopBar(
          title: _isEdit ? 'Edit Listing' : 'New Listing',
          onBack: () => Navigator.pop(context)),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (_error != null) ErrorBanner(message: _error!),
            const FieldLabel('Title *'),
            TextFormField(
                controller: _titleCtrl,
                decoration:
                    const InputDecoration(hintText: 'e.g. Salle El Bahia'),
                validator: (v) => v == null || v.isEmpty ? 'Required' : null),
            const SizedBox(height: 16),
            const FieldLabel('Category *'),
            DropdownButtonFormField<String>(
              initialValue: _category,
              decoration: const InputDecoration(),
              items: _cats
                  .map((c) => DropdownMenuItem(
                      value: c,
                      child: Text('${c[0].toUpperCase()}${c.substring(1)}')))
                  .toList(),
              onChanged: (v) => setState(() => _category = v!),
            ),
            const SizedBox(height: 16),
            const FieldLabel('Description *'),
            TextFormField(
                controller: _descCtrl,
                maxLines: 3,
                decoration:
                    const InputDecoration(hintText: 'Describe your service...'),
                validator: (v) => v == null || v.isEmpty ? 'Required' : null),
            const SizedBox(height: 16),
            Row(children: [
              Expanded(
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                    const FieldLabel('City *'),
                    TextFormField(
                        controller: _cityCtrl,
                        decoration: const InputDecoration(hintText: 'Algiers'),
                        validator: (v) =>
                            v == null || v.isEmpty ? 'Required' : null),
                  ])),
              const SizedBox(width: 12),
              Expanded(
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                    const FieldLabel('Wilaya *'),
                    TextFormField(
                        controller: _wilayaCtrl,
                        decoration: const InputDecoration(hintText: 'Algiers'),
                        validator: (v) =>
                            v == null || v.isEmpty ? 'Required' : null),
                  ])),
            ]),
            const SizedBox(height: 16),
            const FieldLabel('Price Range (DZD) *'),
            Row(children: [
              Expanded(
                  child: TextFormField(
                      controller: _priceMinCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(hintText: 'Min'),
                      validator: (v) =>
                          v == null || v.isEmpty ? 'Required' : null)),
              const SizedBox(width: 12),
              Expanded(
                  child: TextFormField(
                      controller: _priceMaxCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(hintText: 'Max'),
                      validator: (v) =>
                          v == null || v.isEmpty ? 'Required' : null)),
            ]),
            const SizedBox(height: 16),
            const FieldLabel('Capacity'),
            Row(children: [
              Expanded(
                  child: TextFormField(
                      controller: _capMinCtrl,
                      keyboardType: TextInputType.number,
                      decoration:
                          const InputDecoration(hintText: 'Min guests'))),
              const SizedBox(width: 12),
              Expanded(
                  child: TextFormField(
                      controller: _capMaxCtrl,
                      keyboardType: TextInputType.number,
                      decoration:
                          const InputDecoration(hintText: 'Max guests'))),
            ]),
            const SizedBox(height: 16),

            const FieldLabel('Photos'),
            const SizedBox(height: 8),
// 1. The Button to trigger the picker
            InkWell(
              onTap: _showPicker, // This calls the method we added in Step 3
              child: Container(
                height: 100,
                width: double.infinity,
                decoration: BoxDecoration(
                  border: Border.all(color: AppTheme.cardBorder, width: 1),
                  borderRadius: BorderRadius.circular(12),
                  color: AppTheme.surface,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.add_a_photo_outlined,
                        color: AppTheme.primary, size: 30),
                    const SizedBox(height: 8),
                    const Text('Gallery or Camera',
                        style: TextStyle(
                            color: AppTheme.textSecondary, fontSize: 12)),
                  ],
                ),
              ),
            ),

// 2. The Preview Section (shows the actual images instead of text chips)
            if (_images.isNotEmpty) ...[
              const SizedBox(height: 12),
              SizedBox(
                height: 90,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: _images.length,
                  itemBuilder: (context, index) {
                    final path = _images[index];
                    return Container(
                      margin: const EdgeInsets.only(right: 8),
                      width: 90,
                      child: Stack(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: path.startsWith('data:image')
                                ? Image.memory(
                                    base64Decode(path.split(
                                        ',')[1]), // Strip the prefix and decode
                                    fit: BoxFit.cover,
                                    width: 90,
                                    height: 90,
                                  )
                                : Image.network(
                                    path,
                                    fit: BoxFit.cover,
                                    width: 90,
                                    height: 90,
                                    errorBuilder:
                                        (context, error, stackTrace) =>
                                            const Icon(Icons.broken_image),
                                  ),
                          ),
                          Positioned(
                            right: 4,
                            top: 4,
                            child: GestureDetector(
                              onTap: () =>
                                  setState(() => _images.removeAt(index)),
                              child: Container(
                                padding: const EdgeInsets.all(2),
                                decoration: const BoxDecoration(
                                    color: Colors.black54,
                                    shape: BoxShape.circle),
                                child: const Icon(Icons.close,
                                    color: Colors.white, size: 14),
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],

            const SizedBox(height: 16),
            const FieldLabel('Amenities'),
            Row(children: [
              Expanded(
                  child: TextFormField(
                      controller: _amenityCtrl,
                      decoration:
                          const InputDecoration(hintText: 'e.g. Parking, AC'))),
              const SizedBox(width: 8),
              ElevatedButton(
                onPressed: () {
                  if (_amenityCtrl.text.trim().isNotEmpty)
                    setState(() {
                      _amenities.add(_amenityCtrl.text.trim());
                      _amenityCtrl.clear();
                    });
                },
                style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 14)),
                child: const Text('Add'),
              ),
            ]),
            if (_amenities.isNotEmpty) ...[
              const SizedBox(height: 8),
              Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: _amenities
                      .asMap()
                      .entries
                      .map((e) => Chip(
                            label: Text(e.value,
                                style: const TextStyle(fontSize: 12)),
                            deleteIcon: const Icon(Icons.close, size: 14),
                            onDeleted: () =>
                                setState(() => _amenities.removeAt(e.key)),
                            backgroundColor: AppTheme.surface,
                          ))
                      .toList()),
            ],
            const SizedBox(height: 32),
            LoadingButton(
                label: _isEdit ? 'Save Changes' : 'Create Listing',
                onPressed: _save,
                isLoading: _loading),
            const SizedBox(height: 32),
          ]),
        ),
      ),
    );
  }
}
