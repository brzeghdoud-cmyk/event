import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import '../services/auth_provider.dart';
import '../theme.dart';
import '../widgets/shared_widgets.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  List<Booking> _bookings = [];
  List<ProviderListing> _listings = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final r = await Future.wait([
        ApiService.instance.getMyBookings(),
        ApiService.instance.getMyListings(),
      ]);
      if (mounted) {
        setState(() {
          _bookings = r[0] as List<Booking>;
          _listings = r[1] as List<ProviderListing>;
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  int _count(String s) => _bookings.where((b) => b.status == s).length;
  double get _revenue => _bookings
      .where((b) => b.status == 'completed')
      .fold(0, (sum, b) => sum + b.totalPrice);

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().user;
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppTopBar(title: 'Dashboard'),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: AppTheme.primary))
          : RefreshIndicator(
              color: AppTheme.primary,
              onRefresh: _load,
              child: ListView(
                physics: const BouncingScrollPhysics(
                    parent: AlwaysScrollableScrollPhysics()),
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
                children: [
                  // Greeting
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                          colors: [AppTheme.primary, AppTheme.accent],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                            child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Hello, ${user?.firstName ?? 'Provider'} ',
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w800)),
                            const SizedBox(height: 4),
                            const Text("Here's your business today",
                                style: TextStyle(
                                    color: Colors.white70, fontSize: 13)),
                          ],
                        )),
                        CircleAvatar(
                          radius: 24,
                          backgroundColor: Colors.white.withOpacity(0.2),
                          child: Text(user?.initials ?? '?',
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w800,
                                  fontSize: 16)),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),
                  const Text('Overview',
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.textPrimary)),
                  const SizedBox(height: 12),

                  GridView.count(
                    crossAxisCount: 2,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: 1.1,
                    children: [
                      StatCard(
                          label: 'Active Listings',
                          value: '${_listings.where((l) => l.isActive).length}',
                          icon: Icons.storefront_rounded,
                          color: AppTheme.primary),
                      StatCard(
                          label: 'Total Bookings',
                          value: '${_bookings.length}',
                          icon: Icons.calendar_month_rounded,
                          color: AppTheme.info),
                      StatCard(
                          label: 'Pending',
                          value: '${_count('pending_payment')}',
                          icon: Icons.hourglass_empty_rounded,
                          color: AppTheme.warning),
                      StatCard(
                          label: 'Confirmed',
                          value: '${_count('confirmed')}',
                          icon: Icons.check_circle_outline_rounded,
                          color: AppTheme.success),
                    ],
                  ),

                  const SizedBox(height: 20),

                  // Revenue card
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: AppTheme.success.withOpacity(0.07),
                      borderRadius: BorderRadius.circular(16),
                      border:
                          Border.all(color: AppTheme.success.withOpacity(0.2)),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                              color: AppTheme.success.withOpacity(0.15),
                              shape: BoxShape.circle),
                          child: const Icon(Icons.payments_rounded,
                              color: AppTheme.success, size: 28),
                        ),
                        const SizedBox(width: 16),
                        Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Total Revenue',
                                  style: TextStyle(
                                      fontSize: 13,
                                      color: AppTheme.textSecondary)),
                              const SizedBox(height: 4),
                              Text('${_revenue.toInt()} DZD',
                                  style: const TextStyle(
                                      fontSize: 22,
                                      fontWeight: FontWeight.w800,
                                      color: AppTheme.success)),
                              Text(
                                  'from ${_count('completed')} completed bookings',
                                  style: const TextStyle(
                                      fontSize: 11,
                                      color: AppTheme.textSecondary)),
                            ]),
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),

                  if (_bookings.isNotEmpty) ...[
                    Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Recent Bookings',
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800,
                                  color: AppTheme.textPrimary)),
                          Text('${_bookings.length} total',
                              style: const TextStyle(
                                  fontSize: 12, color: AppTheme.textSecondary)),
                        ]),
                    const SizedBox(height: 12),
                    ..._bookings.take(5).map((b) => _BookingTile(booking: b)),
                  ],
                ],
              ),
            ),
    );
  }
}

class _BookingTile extends StatelessWidget {
  final Booking booking;
  const _BookingTile({required this.booking});

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppTheme.cardBorder),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.04),
                blurRadius: 8,
                offset: const Offset(0, 2))
          ],
        ),
        child: Row(children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
                color: AppTheme.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12)),
            child: Center(
                child: Text(
              booking.clientName.isNotEmpty
                  ? booking.clientName[0].toUpperCase()
                  : '?',
              style: const TextStyle(
                  color: AppTheme.primary,
                  fontWeight: FontWeight.w800,
                  fontSize: 18),
            )),
          ),
          const SizedBox(width: 12),
          Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                Text(
                    booking.clientName.isEmpty
                        ? booking.clientEmail
                        : booking.clientName,
                    style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                        color: AppTheme.textPrimary)),
                Text(booking.listingTitle,
                    style: const TextStyle(
                        fontSize: 12, color: AppTheme.textSecondary)),
                Text(
                    '${booking.eventDate.day}/${booking.eventDate.month}/${booking.eventDate.year}',
                    style: const TextStyle(
                        fontSize: 11, color: AppTheme.textSecondary)),
              ])),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
                color: booking.statusColor.withOpacity(0.12),
                borderRadius: BorderRadius.circular(8)),
            child: Text(booking.statusLabel,
                style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: booking.statusColor)),
          ),
        ]),
      );
}
