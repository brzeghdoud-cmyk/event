import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import '../theme.dart';
import '../widgets/shared_widgets.dart';

class BookingsScreen extends StatefulWidget {
  final Function(
      {required String threadId,
      required String clientId,
      required String clientName,
      String? clientAvatar,
      String? listingTitle})? onChatTap;

  const BookingsScreen({super.key, this.onChatTap});

  @override
  State<BookingsScreen> createState() => _BookingsScreenState();
}

class _BookingsScreenState extends State<BookingsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tab;
  List<Booking> _all = [];
  bool _loading = true;
  final _tabs = ['All', 'Pending', 'Confirmed', 'Completed', 'Cancelled'];

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: _tabs.length, vsync: this);
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final data = await ApiService.instance.getMyBookings();
      if (mounted)
        setState(() {
          _all = data;
          _loading = false;
        });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  List<Booking> _filtered(String tab) {
    if (tab == 'All') return _all;
    const map = {
      'Pending': 'pending_payment',
      'Confirmed': 'confirmed',
      'Completed': 'completed',
      'Cancelled': 'cancelled',
    };
    return _all
        .where((b) => b.status == (map[tab] ?? tab.toLowerCase()))
        .toList();
  }

  Future<void> _action(Booking b, String action) async {
    String? reason;
    if (action == 'reject') {
      reason = await _askReason();
      if (reason == null) return;
    }
    try {
      if (action == 'accept') await ApiService.instance.acceptBooking(b.id);
      if (action == 'reject')
        await ApiService.instance.rejectBooking(b.id, reason!);
      if (action == 'complete') await ApiService.instance.completeBooking(b.id);
      _load();
    } catch (e) {
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(e.toString().replaceAll('Exception: ', ''))));
    }
  }

  Future<String?> _askReason() async {
    final ctrl = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Rejection Reason',
            style: TextStyle(fontWeight: FontWeight.w800)),
        content: TextField(
            controller: ctrl,
            maxLines: 3,
            decoration: const InputDecoration(
                hintText: 'Explain why you are rejecting...',
                border: OutlineInputBorder())),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () => Navigator.pop(
                context,
                ctrl.text.trim().isEmpty
                    ? 'No reason given'
                    : ctrl.text.trim()),
            child: const Text('Submit'),
          ),
        ],
      ),
    );
  }

  Future<void> _openChat(Booking b) async {
    // Create or get thread then open chat
    try {
      final thread =
          await ApiService.instance.createThread(b.clientId, b.listingId);
      if (widget.onChatTap != null) {
        widget.onChatTap!(
          threadId: thread.id,
          clientId: b.clientId,
          clientName: b.clientName,
          listingTitle: b.listingTitle,
        );
      }
    } catch (e) {
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(e.toString().replaceAll('Exception: ', ''))));
    }
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppTopBar(title: 'Bookings', actions: [
        IconButton(
            icon: const Icon(Icons.refresh_rounded, color: AppTheme.primary),
            onPressed: _load),
      ]),
      body: Column(children: [
        Container(
          color: Colors.white,
          child: TabBar(
            controller: _tab,
            labelColor: AppTheme.primary,
            unselectedLabelColor: AppTheme.textSecondary,
            indicatorColor: AppTheme.primary,
            indicatorWeight: 3,
            isScrollable: true,
            tabs: _tabs.map((t) => Tab(text: t)).toList(),
          ),
        ),
        Expanded(
          child: _loading
              ? const Center(
                  child: CircularProgressIndicator(color: AppTheme.primary))
              : TabBarView(
                  controller: _tab,
                  children: _tabs.map((tab) {
                    final list = _filtered(tab);
                    if (list.isEmpty)
                      return Center(
                          child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.calendar_today_outlined,
                              size: 48, color: AppTheme.textSecondary),
                          const SizedBox(height: 12),
                          Text('No $tab bookings',
                              style: const TextStyle(
                                  color: AppTheme.textSecondary)),
                        ],
                      ));
                    return RefreshIndicator(
                      color: AppTheme.primary,
                      onRefresh: _load,
                      child: ListView.builder(
                        physics: const BouncingScrollPhysics(
                            parent: AlwaysScrollableScrollPhysics()),
                        padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
                        itemCount: list.length,
                        itemBuilder: (_, i) => _BookingCard(
                          booking: list[i],
                          onAccept: list[i].status == 'pending_payment'
                              ? () => _action(list[i], 'accept')
                              : null,
                          onReject: (list[i].status == 'pending_payment' ||
                                  list[i].status == 'confirmed')
                              ? () => _action(list[i], 'reject')
                              : null,
                          onComplete: list[i].status == 'confirmed'
                              ? () => _action(list[i], 'complete')
                              : null,
                          onChat: () => _openChat(list[i]),
                        ),
                      ),
                    );
                  }).toList(),
                ),
        ),
      ]),
    );
  }
}

class _BookingCard extends StatelessWidget {
  final Booking booking;
  final VoidCallback? onAccept, onReject, onComplete, onChat;
  const _BookingCard(
      {required this.booking,
      this.onAccept,
      this.onReject,
      this.onComplete,
      this.onChat});

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppTheme.cardBorder),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 10,
                offset: const Offset(0, 3))
          ],
        ),
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                      color: AppTheme.primary.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12)),
                  child: Center(
                      child: Text(
                    booking.clientName.isNotEmpty
                        ? booking.clientName[0].toUpperCase()
                        : '?',
                    style: const TextStyle(
                        color: AppTheme.primary,
                        fontWeight: FontWeight.w800,
                        fontSize: 18),
                  )),
                ),
                const SizedBox(width: 12),
                Expanded(
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                      Text(
                          booking.clientName.isEmpty
                              ? booking.clientEmail
                              : booking.clientName,
                          style: const TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 15,
                              color: AppTheme.textPrimary)),
                      Text(booking.clientEmail,
                          style: const TextStyle(
                              fontSize: 12, color: AppTheme.textSecondary)),
                    ])),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                      color: booking.statusColor.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(8)),
                  child: Text(booking.statusLabel,
                      style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: booking.statusColor)),
                ),
              ]),
              const SizedBox(height: 12),
              const Divider(height: 1),
              const SizedBox(height: 12),
              _Row(Icons.storefront_rounded, booking.listingTitle),
              const SizedBox(height: 5),
              _Row(Icons.calendar_today_rounded,
                  '${booking.eventDate.day}/${booking.eventDate.month}/${booking.eventDate.year}'),
              const SizedBox(height: 5),
              _Row(Icons.people_rounded, '${booking.guestCount} guests'),
              if (booking.totalPrice > 0) ...[
                const SizedBox(height: 5),
                _Row(Icons.payments_outlined,
                    '${booking.totalPrice.toInt()} DZD'),
              ],
              if (booking.clientPhone != null) ...[
                const SizedBox(height: 5),
                _Row(Icons.phone_rounded, booking.clientPhone!),
              ],
              if (booking.specialRequests != null &&
                  booking.specialRequests!.isNotEmpty) ...[
                const SizedBox(height: 5),
                _Row(Icons.notes_rounded, booking.specialRequests!),
              ],
            ]),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
            child: Column(children: [
              if (onAccept != null || onReject != null)
                Row(children: [
                  if (onAccept != null)
                    Expanded(
                        child: ElevatedButton.icon(
                      onPressed: onAccept,
                      icon: const Icon(Icons.check_rounded, size: 16),
                      label:
                          const Text('Accept', style: TextStyle(fontSize: 13)),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.success,
                          padding: const EdgeInsets.symmetric(vertical: 10)),
                    )),
                  if (onAccept != null && onReject != null)
                    const SizedBox(width: 10),
                  if (onReject != null)
                    Expanded(
                        child: OutlinedButton.icon(
                      onPressed: onReject,
                      icon: const Icon(Icons.close_rounded, size: 16),
                      label:
                          const Text('Reject', style: TextStyle(fontSize: 13)),
                      style: OutlinedButton.styleFrom(
                          foregroundColor: AppTheme.error,
                          side: const BorderSide(color: AppTheme.error),
                          padding: const EdgeInsets.symmetric(vertical: 10)),
                    )),
                ]),
              if (onComplete != null) ...[
                const SizedBox(height: 8),
                SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: onComplete,
                      icon: const Icon(Icons.done_all_rounded, size: 16),
                      label: const Text('Mark as Completed',
                          style: TextStyle(fontSize: 13)),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.info,
                          padding: const EdgeInsets.symmetric(vertical: 10)),
                    )),
              ],
              const SizedBox(height: 8),
              SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: onChat,
                    icon:
                        const Icon(Icons.chat_bubble_outline_rounded, size: 16),
                    label: const Text('Chat with Client',
                        style: TextStyle(fontSize: 13)),
                    style: OutlinedButton.styleFrom(
                        foregroundColor: AppTheme.primary,
                        side: const BorderSide(color: AppTheme.primary),
                        padding: const EdgeInsets.symmetric(vertical: 10)),
                  )),
            ]),
          ),
        ]),
      );
}

class _Row extends StatelessWidget {
  final IconData icon;
  final String text;
  const _Row(this.icon, this.text);

  @override
  Widget build(BuildContext context) => Row(children: [
        Icon(icon, size: 15, color: AppTheme.textSecondary),
        const SizedBox(width: 6),
        Expanded(
            child: Text(text,
                style: const TextStyle(
                    fontSize: 13, color: AppTheme.textSecondary))),
      ]);
}
