import 'package:flutter/material.dart';
import '../widgets/shared_widgets.dart';
import 'dashboard_screen.dart';
import 'listings_screen.dart';
import 'bookings_screen.dart';
import 'chat_screen.dart';
import 'profile_screen.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => MainShellState();
}

class MainShellState extends State<MainShell> {
  int _index = 0;

  void goToChat({required String threadId, required String clientId,
      required String clientName, String? clientAvatar, String? listingTitle}) {
    setState(() => _index = 3);
    // Push chat detail on top of chat list
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ChatDetailScreen(
          threadId: threadId,
          otherUserId: clientId,
          otherUserName: clientName,
          otherUserAvatar: clientAvatar,
          listingTitle: listingTitle,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: [
          const DashboardScreen(),
          const ListingsScreen(),
          BookingsScreen(onChatTap: goToChat),
          const ChatScreen(),
          const ProfileScreen(),
        ],
      ),
      bottomNavigationBar: BizBottomNav(
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
      ),
    );
  }
}
