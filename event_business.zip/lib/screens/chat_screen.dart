// provider chat_screen.dart
import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import '../theme.dart';
import '../widgets/shared_widgets.dart';

// ── Thread List ───────────────────────────────────────────────────────────────

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  List<ChatThread> _threads = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final threads = await ApiService.instance.getThreads();
      if (mounted) {
        setState(() {
          _threads = threads;
          _loading = false;
        });
      }
    } catch (e) {
      if (mounted)
        setState(() {
          _error = e.toString();
          _loading = false;
        });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppTopBar(title: 'Messages'),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: AppTheme.primary))
          : _error != null
              ? Center(
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                      const Icon(Icons.wifi_off_rounded,
                          size: 48, color: AppTheme.textSecondary),
                      const SizedBox(height: 12),
                      Text(_error!,
                          textAlign: TextAlign.center,
                          style:
                              const TextStyle(color: AppTheme.textSecondary)),
                      const SizedBox(height: 16),
                      ElevatedButton.icon(
                          onPressed: _load,
                          icon: const Icon(Icons.refresh_rounded),
                          label: const Text('Retry')),
                    ]))
              : _threads.isEmpty
                  ? Center(
                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                          Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                                color: AppTheme.primary.withOpacity(0.08),
                                shape: BoxShape.circle),
                            child: const Icon(Icons.chat_bubble_outline_rounded,
                                size: 40, color: AppTheme.primary),
                          ),
                          const SizedBox(height: 16),
                          const Text('No messages yet',
                              style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 16,
                                  color: AppTheme.textPrimary)),
                          const SizedBox(height: 6),
                          const Text('Clients who book will appear here',
                              style: TextStyle(
                                  color: AppTheme.textSecondary, fontSize: 13)),
                        ]))
                  : RefreshIndicator(
                      color: AppTheme.primary,
                      onRefresh: _load,
                      child: ListView.separated(
                        physics: const BouncingScrollPhysics(
                            parent: AlwaysScrollableScrollPhysics()),
                        padding: const EdgeInsets.only(bottom: 100),
                        itemCount: _threads.length,
                        separatorBuilder: (_, __) =>
                            const Divider(height: 1, indent: 72),
                        itemBuilder: (_, i) => _ThreadTile(
                          thread: _threads[i],
                          onTap: () async {
                            await Navigator.push(
                                context,
                                AppTheme.smoothRoute(
                                  ChatDetailScreen(
                                    threadId: _threads[i].id,
                                    otherUserId: _threads[i].otherUserId,
                                    otherUserName: _threads[i].otherUserName,
                                    otherUserAvatar:
                                        _threads[i].otherUserAvatar,
                                    listingTitle: _threads[i].listingTitle,
                                  ),
                                ));
                            _load();
                          },
                        ),
                      ),
                    ),
    );
  }
}

class _ThreadTile extends StatelessWidget {
  final ChatThread thread;
  final VoidCallback onTap;
  const _ThreadTile({required this.thread, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final hasUnread = thread.unreadCount > 0;
    return ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      leading: CircleAvatar(
        radius: 26,
        backgroundColor: AppTheme.primary.withOpacity(0.12),
        backgroundImage: thread.otherUserAvatar != null
            ? NetworkImage(thread.otherUserAvatar!)
            : null,
        child: thread.otherUserAvatar == null
            ? Text(
                thread.otherUserName.isNotEmpty
                    ? thread.otherUserName[0].toUpperCase()
                    : '?',
                style: const TextStyle(
                    color: AppTheme.primary,
                    fontWeight: FontWeight.w800,
                    fontSize: 18))
            : null,
      ),
      title: Text(
        thread.otherUserName.isEmpty ? 'Client' : thread.otherUserName,
        style: TextStyle(
            fontWeight: hasUnread ? FontWeight.w800 : FontWeight.w600,
            fontSize: 14,
            color: AppTheme.textPrimary),
      ),
      subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (thread.listingTitle != null)
          Text(thread.listingTitle!,
              style: const TextStyle(
                  fontSize: 11,
                  color: AppTheme.primary,
                  fontWeight: FontWeight.w600),
              maxLines: 1,
              overflow: TextOverflow.ellipsis),
        Text(
          thread.lastMessage.isEmpty ? 'No messages yet' : thread.lastMessage,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
              fontSize: 13,
              color: hasUnread ? AppTheme.textPrimary : AppTheme.textSecondary,
              fontWeight: hasUnread ? FontWeight.w600 : FontWeight.normal),
        ),
      ]),
      trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(_fmt(thread.lastMessageAt),
                style: TextStyle(
                    fontSize: 11,
                    color:
                        hasUnread ? AppTheme.primary : AppTheme.textSecondary,
                    fontWeight:
                        hasUnread ? FontWeight.w700 : FontWeight.normal)),
            if (hasUnread) ...[
              const SizedBox(height: 4),
              Container(
                width: 20,
                height: 20,
                decoration: const BoxDecoration(
                    color: AppTheme.primary, shape: BoxShape.circle),
                child: Center(
                    child: Text(
                  '${thread.unreadCount > 9 ? '9+' : thread.unreadCount}',
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.w800),
                )),
              ),
            ],
          ]),
    );
  }

  String _fmt(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 1) return 'now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m';
    if (diff.inHours < 24) return '${diff.inHours}h';
    if (diff.inDays < 7) return '${diff.inDays}d';
    return '${dt.day}/${dt.month}';
  }
}

// ── Chat Detail ───────────────────────────────────────────────────────────────

class ChatDetailScreen extends StatefulWidget {
  final String threadId;
  final String otherUserId;
  final String otherUserName;
  final String? otherUserAvatar;
  final String? listingTitle;

  const ChatDetailScreen({
    super.key,
    required this.threadId,
    required this.otherUserId,
    required this.otherUserName,
    this.otherUserAvatar,
    this.listingTitle,
  });

  @override
  State<ChatDetailScreen> createState() => _ChatDetailScreenState();
}

class _ChatDetailScreenState extends State<ChatDetailScreen> {
  final _msgCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  List<ChatMessage> _messages = [];
  bool _loading = true;
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final msgs = await ApiService.instance.getMessages(widget.threadId);
      await ApiService.instance.markRead(widget.threadId);
      if (mounted) {
        setState(() {
          _messages = msgs;
          _loading = false;
        });
        _scrollToBottom();
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _send() async {
    final text = _msgCtrl.text.trim();
    if (text.isEmpty || _sending) return;
    _msgCtrl.clear();
    setState(() => _sending = true);
    try {
      final msg = await ApiService.instance.sendMessage(widget.threadId, text);
      if (mounted) {
        setState(() {
          _messages.add(msg);
          _sending = false;
        });
        _scrollToBottom();
      }
    } catch (_) {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  void dispose() {
    _msgCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF0F0F5),
      appBar: _ChatAppBar(
        name: widget.otherUserName.isEmpty ? 'Client' : widget.otherUserName,
        avatar: widget.otherUserAvatar,
        listingTitle: widget.listingTitle,
        onBack: () => Navigator.pop(context),
      ),
      body: Column(children: [
        Expanded(
          child: _loading
              ? const Center(
                  child: CircularProgressIndicator(color: AppTheme.primary))
              : _messages.isEmpty
                  ? Center(
                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                          Icon(Icons.chat_bubble_outline_rounded,
                              size: 48,
                              color: AppTheme.primary.withOpacity(0.3)),
                          const SizedBox(height: 12),
                          const Text('Start the conversation 💬',
                              style: TextStyle(color: AppTheme.textSecondary)),
                        ]))
                  : ListView.builder(
                      controller: _scrollCtrl,
                      reverse: true, // ← ADD THIS
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
                      itemCount: _messages.length,
                      itemBuilder: (_, i) {
                        // reverse index so newest is at bottom visually
                        final idx = _messages.length - 1 - i;
                        final msg = _messages[idx];
                        final showDate = idx == 0 ||
                            !_sameDay(
                                _messages[idx - 1].createdAt, msg.createdAt);
                        return Column(children: [
                          if (showDate) _DateDivider(msg.createdAt),
                          _Bubble(msg: msg),
                        ]);
                      },
                    ),
        ),
        Container(
          color: Colors.white,
          padding: EdgeInsets.fromLTRB(
              12, 10, 12, MediaQuery.of(context).padding.bottom + 10),
          child: Row(children: [
            Expanded(
              child: TextField(
                controller: _msgCtrl,
                maxLines: null,
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _send(),
                decoration: InputDecoration(
                  hintText: 'Type a message...',
                  hintStyle: const TextStyle(color: AppTheme.textSecondary),
                  filled: true,
                  fillColor: const Color(0xFFF0F0F5),
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(24),
                      borderSide: BorderSide.none),
                ),
              ),
            ),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: _send,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: _sending
                      ? AppTheme.primary.withOpacity(0.6)
                      : AppTheme.primary,
                  shape: BoxShape.circle,
                ),
                child: _sending
                    ? const Padding(
                        padding: EdgeInsets.all(12),
                        child: CircularProgressIndicator(
                            color: Colors.white, strokeWidth: 2))
                    : const Icon(Icons.send_rounded,
                        color: Colors.white, size: 20),
              ),
            ),
          ]),
        ),
      ]),
    );
  }

  bool _sameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;
}

class _ChatAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String name;
  final String? avatar, listingTitle;
  final VoidCallback onBack;
  const _ChatAppBar(
      {required this.name,
      this.avatar,
      this.listingTitle,
      required this.onBack});

  @override
  Widget build(BuildContext context) => AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon:
              const Icon(Icons.arrow_back_ios_rounded, color: AppTheme.primary),
          onPressed: onBack,
        ),
        title: Row(children: [
          CircleAvatar(
            radius: 18,
            backgroundColor: AppTheme.primary.withOpacity(0.12),
            backgroundImage: avatar != null ? NetworkImage(avatar!) : null,
            child: avatar == null
                ? Text(name.isNotEmpty ? name[0].toUpperCase() : '?',
                    style: const TextStyle(
                        color: AppTheme.primary,
                        fontWeight: FontWeight.w800,
                        fontSize: 14))
                : null,
          ),
          const SizedBox(width: 10),
          Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                Text(name,
                    style: const TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 15,
                        color: AppTheme.textPrimary)),
                if (listingTitle != null)
                  Text(listingTitle!,
                      style: const TextStyle(
                          fontSize: 11, color: AppTheme.primary),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
              ])),
        ]),
        centerTitle: false,
      );

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}

class _Bubble extends StatelessWidget {
  final ChatMessage msg;
  const _Bubble({required this.msg});

  @override
  Widget build(BuildContext context) {
    if (msg.type == 'system') {
      return Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.06),
            borderRadius: BorderRadius.circular(12)),
        child: Text(msg.content,
            textAlign: TextAlign.center,
            style:
                const TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
      );
    }

    return Align(
      alignment: msg.isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 4),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        constraints:
            BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
        decoration: BoxDecoration(
          color: msg.isMe ? AppTheme.primary : Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(18),
            topRight: const Radius.circular(18),
            bottomLeft: Radius.circular(msg.isMe ? 18 : 4),
            bottomRight: Radius.circular(msg.isMe ? 4 : 18),
          ),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.06),
                blurRadius: 6,
                offset: const Offset(0, 2))
          ],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text(msg.content,
              style: TextStyle(
                  color: msg.isMe ? Colors.white : AppTheme.textPrimary,
                  fontSize: 14,
                  height: 1.4)),
          const SizedBox(height: 4),
          Text(
              '${msg.createdAt.hour}:${msg.createdAt.minute.toString().padLeft(2, '0')}',
              style: TextStyle(
                  fontSize: 10,
                  color: msg.isMe ? Colors.white60 : AppTheme.textSecondary)),
        ]),
      ),
    );
  }
}

class _DateDivider extends StatelessWidget {
  final DateTime date;
  const _DateDivider(this.date);

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    String label;
    if (date.year == now.year && date.month == now.month && date.day == now.day)
      label = 'Today';
    else if (date.year == now.year &&
        date.month == now.month &&
        date.day == now.day - 1)
      label = 'Yesterday';
    else
      label = '${date.day}/${date.month}/${date.year}';

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(children: [
        const Expanded(child: Divider()),
        Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Text(label,
                style: const TextStyle(
                    fontSize: 11, color: AppTheme.textSecondary))),
        const Expanded(child: Divider()),
      ]),
    );
  }
}
